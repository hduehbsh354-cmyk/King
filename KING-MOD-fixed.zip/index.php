<?php
/**
 * KING MOD - Main Web App Entry Point
 */

// If direct request, serve index.html content
require_once __DIR__ . '/index.html';
