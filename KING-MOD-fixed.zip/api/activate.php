<?php
/**
 * KING MOD - API Endpoint: /api/activate
 * Authenticates license keys and returns activation session + Happ deep link
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method Not Allowed']);
    exit;
}

require_once __DIR__ . '/../database.php';

$raw = file_get_contents('php://input');
$body = json_decode($raw, true);

if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON payload']);
    exit;
}

$key = trim($body['license_key'] ?? '');
$deviceId = trim($body['device_id'] ?? '');
$deviceName = trim($body['device_name'] ?? '');

if (empty($key)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Access key is required']);
    exit;
}

$db = RaxDatabase::getInstance();
$result = $db->activateKey($key, $deviceId, $deviceName);

if ($result['status'] === 'success') {
    http_response_code(200);
    echo json_encode($result, JSON_UNESCAPED_SLASHES);
} else {
    http_response_code(400);
    echo json_encode($result, JSON_UNESCAPED_SLASHES);
}
