<?php
/**
 * KING MOD - Admin API Endpoint
 * Manage license keys, activations, and durations
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../database.php';
$config = require __DIR__ . '/../config.php';
$adminPass = $config['admin_password'] ?? 'mohamed0112139';

$db = RaxDatabase::getInstance();

$method = $_SERVER['REQUEST_METHOD'];
$req = ($method === 'POST') ? json_decode(file_get_contents('php://input'), true) : $_GET;
if (!is_array($req)) $req = [];

// Simple password authorization
$auth = $req['password'] ?? ($_SERVER['HTTP_AUTHORIZATION'] ?? '');
$auth = str_replace('Bearer ', '', $auth);

if ($auth !== $adminPass) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Unauthorized: Invalid admin password']);
    exit;
}

$action = $req['action'] ?? ($method === 'GET' ? 'list' : '');

switch ($action) {
    case 'list':
        $keys = $db->listAllKeys();
        echo json_encode(['ok' => true, 'keys' => $keys]);
        break;

    case 'create':
        $keyName = trim($req['key'] ?? '');
        if (empty($keyName)) {
            // Auto generate key if not supplied
            $keyName = 'RAX-' . strtoupper(bin2hex(random_bytes(2))) . '-' . strtoupper(bin2hex(random_bytes(2))) . '-' . strtoupper(bin2hex(random_bytes(2)));
        }
        $days = intval($req['duration_days'] ?? 30);
        $subUrl = trim($req['subscription_url'] ?? '');
        $ok = $db->createKey($keyName, $days, $subUrl);
        echo json_encode([
            'ok' => $ok,
            'message' => $ok ? 'Key created successfully' : 'Failed to create key',
            'key' => $keyName,
            'duration_days' => $days
        ]);
        break;

    case 'delete':
        $targetKey = trim($req['key'] ?? '');
        if (empty($targetKey)) {
            echo json_encode(['ok' => false, 'message' => 'Key name is required']);
            exit;
        }
        $ok = $db->deleteKey($targetKey);
        echo json_encode(['ok' => $ok, 'message' => $ok ? 'Key deleted' : 'Failed to delete key']);
        break;

    case 'unbind':
        $targetKey = trim($req['key'] ?? '');
        if (empty($targetKey)) {
            echo json_encode(['ok' => false, 'message' => 'Key name is required']);
            exit;
        }
        $ok = $db->unbindKey($targetKey);
        echo json_encode(['ok' => $ok, 'message' => $ok ? 'Device unbound successfully' : 'Failed to unbind device']);
        break;

    default:
        http_response_code(400);
        echo json_encode(['ok' => false, 'message' => 'Unknown action']);
        break;
}
