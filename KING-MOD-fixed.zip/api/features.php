<?php
/**
 * KING MOD - API Endpoint: /api/features
 * Fetches and updates in-game mod feature configurations
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method Not Allowed']);
    exit;
}

require_once __DIR__ . '/../database.php';

$raw = file_get_contents('php://input');
$body = json_decode($raw, true);

if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Invalid JSON payload']);
    exit;
}

$token = trim($body['token'] ?? '');
$key = trim($body['key'] ?? '');

$db = RaxDatabase::getInstance();

// 1. Single feature update
if (isset($body['feature']) && isset($body['value'])) {
    $feat = trim($body['feature']);
    $val = trim($body['value']);
    $ok = $db->updateFeature($token, $key, $feat, $val);
    echo json_encode(['ok' => $ok, 'message' => $ok ? 'Feature updated' : 'Update failed']);
    exit;
}

// 2. Marker style update
if (isset($body['marker'])) {
    $val = trim($body['marker']);
    $ok = $db->updateFeature($token, $key, 'marker', $val);
    echo json_encode(['ok' => $ok, 'message' => $ok ? 'Marker updated' : 'Update failed']);
    exit;
}

// 3. Multi-field update (e.g. Aim Lag freeze_fire & freeze_scope)
if (isset($body['freeze_fire']) || isset($body['freeze_scope'])) {
    $updates = [];
    if (isset($body['freeze_fire'])) $updates['freeze_fire'] = $body['freeze_fire'];
    if (isset($body['freeze_scope'])) $updates['freeze_scope'] = $body['freeze_scope'];
    $ok = $db->updateFeaturesMulti($token, $key, $updates);
    echo json_encode(['ok' => $ok, 'message' => $ok ? 'Features updated' : 'Update failed']);
    exit;
}

// 4. Default: Query current features
$features = $db->getFeatures($token, $key);
if (empty($features)) {
    $features = [
        'moco' => 1,
        'aimbot' => 1,
        'freeze_fire' => 0,
        'freeze_scope' => 0,
        'icewall' => 0,
        'auto_revive' => 0,
        'marker' => '5'
    ];
}

echo json_encode(['features' => $features], JSON_UNESCAPED_SLASHES);
