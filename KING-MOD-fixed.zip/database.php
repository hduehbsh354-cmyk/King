<?php
/**
 * KING MOD - Database Abstraction Layer
 * Supports SQLite (PDO) with automatic fallback to JSON flat file.
 */

class RaxDatabase {
    private static $instance = null;
    private $config;
    private $useSqlite = false;
    private $pdo = null;
    private $jsonPath;

    private function __construct() {
        $this->config = require __DIR__ . '/config.php';
        $this->jsonPath = $this->config['json_path'];

        $mode = $this->config['storage_mode'] ?? 'auto';
        $sqliteAvailable = extension_loaded('pdo_sqlite');

        if (($mode === 'sqlite' || $mode === 'auto') && $sqliteAvailable) {
            try {
                $dir = dirname($this->config['sqlite_path']);
                if (!is_dir($dir)) mkdir($dir, 0755, true);

                $this->pdo = new PDO('sqlite:' . $this->config['sqlite_path']);
                $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
                $this->initSqliteSchema();
                $this->useSqlite = true;
            } catch (Exception $e) {
                $this->useSqlite = false;
            }
        }

        if (!$this->useSqlite) {
            $dir = dirname($this->jsonPath);
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            if (!file_exists($this->jsonPath)) {
                file_put_contents($this->jsonPath, json_encode(['keys' => []], JSON_PRETTY_PRINT));
            }
        }
    }

    public static function getInstance(): RaxDatabase {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function initSqliteSchema() {
        $sql = "
            CREATE TABLE IF NOT EXISTS license_keys (
                key TEXT PRIMARY KEY,
                status TEXT DEFAULT 'active',
                created_at TEXT,
                activated_at TEXT,
                duration_days INTEGER DEFAULT 30,
                expires_at TEXT,
                device_id TEXT,
                device_name TEXT,
                token TEXT,
                subscription_url TEXT,
                happ_deep_link TEXT,
                features TEXT
            );
        ";
        $this->pdo->exec($sql);

        // Migrate demo keys from JSON if SQLite is empty
        $count = $this->pdo->query("SELECT count(*) FROM license_keys")->fetchColumn();
        if ($count == 0 && file_exists($this->jsonPath)) {
            $jsonData = json_decode(file_get_contents($this->jsonPath), true);
            if (!empty($jsonData['keys'])) {
                $stmt = $this->pdo->prepare("
                    INSERT OR REPLACE INTO license_keys 
                    (key, status, created_at, activated_at, duration_days, expires_at, device_id, device_name, token, subscription_url, happ_deep_link, features)
                    VALUES (:key, :status, :created_at, :activated_at, :duration_days, :expires_at, :device_id, :device_name, :token, :subscription_url, :happ_deep_link, :features)
                ");
                foreach ($jsonData['keys'] as $k => $item) {
                    $stmt->execute([
                        ':key'              => $item['key'],
                        ':status'           => $item['status'] ?? 'active',
                        ':created_at'       => $item['created_at'] ?? date('c'),
                        ':activated_at'     => $item['activated_at'] ?? null,
                        ':duration_days'    => $item['duration_days'] ?? 30,
                        ':expires_at'       => $item['expires_at'] ?? null,
                        ':device_id'        => $item['device_id'] ?? null,
                        ':device_name'      => $item['device_name'] ?? null,
                        ':token'            => $item['token'] ?? '',
                        ':subscription_url' => $item['subscription_url'] ?? '',
                        ':happ_deep_link'   => $item['happ_deep_link'] ?? '',
                        ':features'         => json_encode($item['features'] ?? [])
                    ]);
                }
            }
        }
    }

    /* ── JSON Helpers ── */
    private function readJson(): array {
        if (!file_exists($this->jsonPath)) return ['keys' => []];
        $content = file_get_contents($this->jsonPath);
        $data = json_decode($content, true);
        return is_array($data) ? $data : ['keys' => []];
    }

    private function writeJson(array $data): bool {
        return file_put_contents($this->jsonPath, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) !== false;
    }

    /* ── License Key Operations ── */

    public function getKey(string $key) {
        $key = trim($key);
        if ($this->useSqlite) {
            $stmt = $this->pdo->prepare("SELECT * FROM license_keys WHERE key = :key");
            $stmt->execute([':key' => $key]);
            $row = $stmt->fetch();
            if ($row) {
                $row['features'] = json_decode($row['features'] ?? '{}', true) ?: [];
                return $row;
            }
            return null;
        } else {
            $data = $this->readJson();
            return $data['keys'][$key] ?? null;
        }
    }

    public function getKeyByToken(string $token) {
        $token = trim($token);
        if (empty($token)) return null;

        if ($this->useSqlite) {
            $stmt = $this->pdo->prepare("SELECT * FROM license_keys WHERE token = :token");
            $stmt->execute([':token' => $token]);
            $row = $stmt->fetch();
            if ($row) {
                $row['features'] = json_decode($row['features'] ?? '{}', true) ?: [];
                return $row;
            }
            return null;
        } else {
            $data = $this->readJson();
            foreach ($data['keys'] as $k => $item) {
                if (($item['token'] ?? '') === $token) {
                    return $item;
                }
            }
            return null;
        }
    }

    public function activateKey(string $key, string $deviceId, string $deviceName): array {
        $row = $this->getKey($key);
        if (!$row) {
            return ['status' => 'error', 'message' => 'Invalid license key'];
        }

        if (($row['status'] ?? 'active') !== 'active') {
            return ['status' => 'error', 'message' => 'License key is suspended or inactive'];
        }

        // Check if already expired
        if (!empty($row['expires_at'])) {
            $exp = strtotime($row['expires_at']);
            if ($exp !== false && time() >= $exp) {
                return ['status' => 'error', 'message' => 'License key has expired'];
            }
        }

        // Device Lock: If bound to another device
        if (!empty($row['device_id']) && $row['device_id'] !== $deviceId) {
            return ['status' => 'error', 'message' => 'License key is bound to another device'];
        }

        $now = time();
        $isFirstActivation = empty($row['activated_at']);

        if ($isFirstActivation) {
            $durationDays = intval($row['duration_days'] ?? 30);
            $expiresTime = $now + ($durationDays * 86400);
            $expiresAt = date('d M Y, H:i', $expiresTime);
            $activatedAt = date('d M Y');
        } else {
            $expiresAt = $row['expires_at'] ?? date('d M Y, H:i', $now + 86400 * 30);
            $activatedAt = $row['activated_at'] ?? date('d M Y');
        }

        // Generate session token
        $token = bin2hex(random_bytes(24));

        // Ensure deep link & subscription url exist
        $subUrl = $row['subscription_url'] ?: ($this->config['default_subscription_base'] . urlencode($key));
        $deepLink = $row['happ_deep_link'] ?: ('happ://add/' . $subUrl);

        // Default features if empty
        $features = $row['features'] ?? [
            'moco' => 1,
            'aimbot' => 1,
            'freeze_fire' => 0,
            'freeze_scope' => 0,
            'icewall' => 0,
            'auto_revive' => 0,
            'marker' => '5'
        ];

        if ($this->useSqlite) {
            $stmt = $this->pdo->prepare("
                UPDATE license_keys 
                SET activated_at = :activated_at,
                    expires_at = :expires_at,
                    device_id = :device_id,
                    device_name = :device_name,
                    token = :token,
                    subscription_url = :subscription_url,
                    happ_deep_link = :happ_deep_link,
                    features = :features
                WHERE key = :key
            ");
            $stmt->execute([
                ':activated_at'     => $activatedAt,
                ':expires_at'       => $expiresAt,
                ':device_id'        => $deviceId,
                ':device_name'      => $deviceName,
                ':token'            => $token,
                ':subscription_url' => $subUrl,
                ':happ_deep_link'   => $deepLink,
                ':features'         => json_encode($features),
                ':key'              => $key
            ]);
        } else {
            $data = $this->readJson();
            $data['keys'][$key]['activated_at'] = $activatedAt;
            $data['keys'][$key]['expires_at'] = $expiresAt;
            $data['keys'][$key]['device_id'] = $deviceId;
            $data['keys'][$key]['device_name'] = $deviceName;
            $data['keys'][$key]['token'] = $token;
            $data['keys'][$key]['subscription_url'] = $subUrl;
            $data['keys'][$key]['happ_deep_link'] = $deepLink;
            $data['keys'][$key]['features'] = $features;
            $this->writeJson($data);
        }

        return [
            'status'           => 'success',
            'token'            => $token,
            'expires_at'       => $expiresAt,
            'subscription_url' => $subUrl,
            'happ_deep_link'   => $deepLink,
            'features'         => $features
        ];
    }

    public function getFeatures(string $token, string $key = ''): array {
        $row = !empty($token) ? $this->getKeyByToken($token) : ($key ? $this->getKey($key) : null);
        if (!$row) return [];
        return $row['features'] ?? [];
    }

    public function updateFeature(string $token, string $key, string $feature, $value): bool {
        $row = !empty($token) ? $this->getKeyByToken($token) : ($key ? $this->getKey($key) : null);
        if (!$row) return false;

        $targetKey = $row['key'];
        $features = $row['features'] ?? [];
        $features[$feature] = $value;

        if ($this->useSqlite) {
            $stmt = $this->pdo->prepare("UPDATE license_keys SET features = :features WHERE key = :key");
            return $stmt->execute([
                ':features' => json_encode($features),
                ':key'      => $targetKey
            ]);
        } else {
            $data = $this->readJson();
            if (isset($data['keys'][$targetKey])) {
                $data['keys'][$targetKey]['features'] = $features;
                return $this->writeJson($data);
            }
            return false;
        }
    }

    public function updateFeaturesMulti(string $token, string $key, array $updatedFeatures): bool {
        $row = !empty($token) ? $this->getKeyByToken($token) : ($key ? $this->getKey($key) : null);
        if (!$row) return false;

        $targetKey = $row['key'];
        $features = $row['features'] ?? [];
        foreach ($updatedFeatures as $k => $v) {
            $features[$k] = $v;
        }

        if ($this->useSqlite) {
            $stmt = $this->pdo->prepare("UPDATE license_keys SET features = :features WHERE key = :key");
            return $stmt->execute([
                ':features' => json_encode($features),
                ':key'      => $targetKey
            ]);
        } else {
            $data = $this->readJson();
            if (isset($data['keys'][$targetKey])) {
                $data['keys'][$targetKey]['features'] = $features;
                return $this->writeJson($data);
            }
            return false;
        }
    }

    /* ── Admin Management Methods ── */

    public function createKey(string $key, int $durationDays = 30, string $customSubUrl = ''): bool {
        $key = trim($key);
        if (empty($key)) return false;

        $subUrl = $customSubUrl ?: ($this->config['default_subscription_base'] . urlencode($key));
        $deepLink = 'happ://add/' . $subUrl;
        $defaultFeatures = [
            'moco' => 1,
            'aimbot' => 1,
            'freeze_fire' => 0,
            'freeze_scope' => 0,
            'icewall' => 0,
            'auto_revive' => 0,
            'marker' => '5'
        ];

        if ($this->useSqlite) {
            $stmt = $this->pdo->prepare("
                INSERT OR REPLACE INTO license_keys
                (key, status, created_at, duration_days, subscription_url, happ_deep_link, features)
                VALUES (:key, 'active', :created_at, :duration_days, :sub_url, :deep_link, :features)
            ");
            return $stmt->execute([
                ':key'           => $key,
                ':created_at'    => date('c'),
                ':duration_days' => $durationDays,
                ':sub_url'       => $subUrl,
                ':deep_link'     => $deepLink,
                ':features'      => json_encode($defaultFeatures)
            ]);
        } else {
            $data = $this->readJson();
            $data['keys'][$key] = [
                'key'              => $key,
                'status'           => 'active',
                'created_at'       => date('c'),
                'activated_at'     => null,
                'duration_days'    => $durationDays,
                'expires_at'       => null,
                'device_id'        => null,
                'device_name'      => null,
                'token'            => '',
                'subscription_url' => $subUrl,
                'happ_deep_link'   => $deepLink,
                'features'         => $defaultFeatures
            ];
            return $this->writeJson($data);
        }
    }

    public function listAllKeys(): array {
        if ($this->useSqlite) {
            $stmt = $this->pdo->query("SELECT * FROM license_keys ORDER BY created_at DESC");
            $rows = $stmt->fetchAll();
            foreach ($rows as &$r) {
                $r['features'] = json_decode($r['features'] ?? '{}', true) ?: [];
            }
            return $rows;
        } else {
            $data = $this->readJson();
            return array_values($data['keys'] ?? []);
        }
    }

    public function deleteKey(string $key): bool {
        $key = trim($key);
        if ($this->useSqlite) {
            $stmt = $this->pdo->prepare("DELETE FROM license_keys WHERE key = :key");
            return $stmt->execute([':key' => $key]);
        } else {
            $data = $this->readJson();
            if (isset($data['keys'][$key])) {
                unset($data['keys'][$key]);
                return $this->writeJson($data);
            }
            return false;
        }
    }

    public function unbindKey(string $key): bool {
        $key = trim($key);
        if ($this->useSqlite) {
            $stmt = $this->pdo->prepare("UPDATE license_keys SET device_id = NULL, device_name = NULL, token = '' WHERE key = :key");
            return $stmt->execute([':key' => $key]);
        } else {
            $data = $this->readJson();
            if (isset($data['keys'][$key])) {
                $data['keys'][$key]['device_id'] = null;
                $data['keys'][$key]['device_name'] = null;
                $data['keys'][$key]['token'] = '';
                return $this->writeJson($data);
            }
            return false;
        }
    }
}
