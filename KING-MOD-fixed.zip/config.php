<?php
/**
 * KING MOD - Server Configuration
 */

return [
    // Storage mode: 'auto', 'sqlite', or 'json'
    // 'auto' uses SQLite PDO if extension is available, otherwise falls back to JSON.
    'storage_mode' => 'auto',

    'sqlite_path' => __DIR__ . '/data/database.sqlite',
    'json_path'   => __DIR__ . '/data/keys.json',

    // Secret token salt for session verification
    'jwt_secret'  => 'RAX_MODS_CYBER_SECRET_KEY_2026_!@#$',

    // Default VPN subscription URL template for Happ app (happ://add/<url>)
    'default_subscription_base' => 'https://raxmods.store/sub/',

    // Admin security token
    'admin_password' => 'mohamed0112139',

    // Default VIP Server count
    'server_count' => 5
];
