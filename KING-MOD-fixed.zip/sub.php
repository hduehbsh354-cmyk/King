<?php
/**
 * KING MOD - Subscription endpoint:  /sub/<key-or-slug>
 * Serves the VPN/proxy configs (base64 list) to Happ and similar apps.
 * Configs are read from data/configs.txt (one link per line).
 * Optional per-key override: data/configs/<id>.txt
 */

header('Cache-Control: no-store, no-cache, must-revalidate');
header('Content-Type: text/plain; charset=utf-8');

function sub_fail(int $code, string $msg) {
    http_response_code($code);
    echo $msg;
    exit;
}

$id = trim(urldecode($_GET['id'] ?? ''));
if ($id === '' || !preg_match('/^[A-Za-z0-9_.\-]{1,100}$/', $id)) {
    sub_fail(404, 'Not Found');
}

require_once __DIR__ . '/database.php';
$db = RaxDatabase::getInstance();

// 1) match by license key, 2) match by subscription slug (last part of subscription_url)
$row = $db->getKey($id);
if (!$row) {
    foreach ($db->listAllKeys() as $r) {
        $url = $r['subscription_url'] ?? '';
        if ($url !== '' && basename(parse_url($url, PHP_URL_PATH) ?: '') === $id) {
            $row = $r;
            break;
        }
    }
}
if (!$row) sub_fail(404, 'Not Found');

if (($row['status'] ?? 'active') !== 'active') sub_fail(403, 'Subscription suspended');
if (empty($row['activated_at'])) sub_fail(403, 'Key not activated yet');

$expTs = 0;
if (!empty($row['expires_at'])) {
    $t = strtotime($row['expires_at']);
    if ($t !== false) $expTs = $t;
}
if ($expTs > 0 && time() >= $expTs) sub_fail(403, 'Subscription expired');

// Load configs
$file = __DIR__ . '/data/configs/' . $id . '.txt';
if (!is_file($file)) $file = __DIR__ . '/data/configs.txt';
$lines = [];
if (is_file($file)) {
    foreach (preg_split('/\r\n|\r|\n/', file_get_contents($file)) as $l) {
        $l = trim($l);
        if ($l !== '' && $l[0] !== '#') $lines[] = $l;
    }
}
if (!$lines) sub_fail(503, 'No configs available on server yet');

header('profile-title: KING MOD');
header('profile-update-interval: 1');
header('subscription-userinfo: upload=0; download=0; total=0; expire=' . $expTs);
echo base64_encode(implode("\n", $lines));
