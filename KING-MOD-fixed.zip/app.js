/**
 * ══════════════════════════════════════════════════════════════════
 * KING MOD - Client Application Controller
 * ══════════════════════════════════════════════════════════════════
 */

(() => {
    'use strict';

    // DOM Elements
    const viewLogin = document.getElementById('view-login');
    const viewApp = document.getElementById('view-app');
    const bottomNav = document.getElementById('bottom-nav');
    const loginForm = document.getElementById('login-form');
    const keyInput = document.getElementById('access-key-input');
    const btnUnlock = document.getElementById('btn-unlock');
    const btnPaste = document.getElementById('btn-paste');
    const toast = document.getElementById('toast');

    const pageTitle = document.getElementById('page-title');
    const navItems = document.querySelectorAll('.nav-item');
    const tabContents = document.querySelectorAll('.tab-content');

    const displayKey = document.getElementById('display-key');
    const btnCopyKey = document.getElementById('btn-copy-key');
    const statActivated = document.getElementById('stat-activated');
    const statExpires = document.getElementById('stat-expires');
    const statDevice = document.getElementById('stat-device');
    const timeLeftDigits = document.getElementById('time-left-digits');
    const radarProgressBar = document.getElementById('radar-progress-bar');
    const btnAddSub = document.getElementById('btn-add-subscription');
    const featCounter = document.getElementById('active-feature-counter');

    const modalGuide = document.getElementById('modal-guide');
    const btnGuide = document.getElementById('btn-getting-started');
    const btnCloseGuide = document.getElementById('btn-close-guide');
    const btnLogout = document.getElementById('btn-logout');

    let currentSession = null;
    let featuresLoaded = false;
    let liveCountdownTimer = null;

    // Detect Device Name
    function detectDevice() {
        const ua = navigator.userAgent;
        if (/iPhone/i.test(ua)) return 'iPhone • iOS';
        if (/iPad/i.test(ua)) return 'iPad • iPadOS';
        if (/Android/i.test(ua)) {
            const match = ua.match(/Android\s([0-9\.]+);\s*([^;\)]+)/i);
            return match ? (match[2].trim().slice(0, 16) + ' • Android') : 'Android Device';
        }
        if (/Windows/i.test(ua)) return 'PC • Windows';
        if (/Mac/i.test(ua)) return 'Mac • macOS';
        if (/Linux/i.test(ua)) return 'Linux Device';
        return 'Mobile Device';
    }

    // Device ID Generation & Storage
    let deviceId = localStorage.getItem('happ_device_id');
    if (!deviceId) {
        deviceId = (typeof crypto !== 'undefined' && crypto.randomUUID) 
            ? crypto.randomUUID() 
            : 'dev_' + Math.random().toString(36).substring(2, 15) + Date.now();
        localStorage.setItem('happ_device_id', deviceId);
    }

    // Toast Alert
    function showToast(msg) {
        if (!toast) return;
        toast.textContent = msg || 'CHANGES SAVED ✓';
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 1600);
    }

    // Paste from Clipboard
    if (btnPaste) {
        btnPaste.addEventListener('click', async () => {
            try {
                if (navigator.clipboard && navigator.clipboard.readText) {
                    const text = await navigator.clipboard.readText();
                    if (text) {
                        keyInput.value = text.trim();
                        showToast('PASTED FROM CLIPBOARD');
                    }
                }
            } catch (_) {
                keyInput.focus();
            }
        });
    }

    // Copy Key
    if (btnCopyKey) {
        btnCopyKey.addEventListener('click', () => {
            if (currentSession && currentSession.key) {
                navigator.clipboard.writeText(currentSession.key);
                showToast('KEY COPIED TO CLIPBOARD');
            }
        });
    }

    // Modal Guide
    if (btnGuide) btnGuide.addEventListener('click', () => modalGuide.classList.add('show'));
    if (btnCloseGuide) btnCloseGuide.addEventListener('click', () => modalGuide.classList.remove('show'));
    if (modalGuide) {
        modalGuide.addEventListener('click', (e) => {
            if (e.target === modalGuide) modalGuide.classList.remove('show');
        });
    }

    // Tab Navigation
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const target = item.dataset.tab;
            navItems.forEach(i => i.classList.remove('active'));
            item.classList.add('active');

            tabContents.forEach(tc => tc.style.display = 'none');
            const activeTab = document.getElementById(`tab-${target}`);
            if (activeTab) activeTab.style.display = 'block';

            if (pageTitle) pageTitle.textContent = target.toUpperCase();

            if (target === 'features' && !featuresLoaded) {
                loadFeatures();
            }
        });
    });

    // Expiry verification helpers
    function parseExpireTime(expireDateStr) {
        if (!expireDateStr) return null;
        const str = String(expireDateStr).trim();
        if (str === '' || str.toUpperCase() === 'ACTIVE') return null;

        let t = null;
        if (!isNaN(str)) {
            const num = parseInt(str, 10);
            t = (num > 1e11) ? num : (num * 1000);
        } else {
            t = new Date(str).getTime();
        }
        return (isNaN(t) || t <= 0) ? null : t;
    }

    function checkIsExpired(expireDateStr) {
        const t = parseExpireTime(expireDateStr);
        if (t === null) return false;
        return Date.now() >= t;
    }

    function handleExpiredSession() {
        if (liveCountdownTimer) clearInterval(liveCountdownTimer);
        if (timeLeftDigits) timeLeftDigits.textContent = 'EXPIRED';
        localStorage.removeItem('zrex_app_session');
        currentSession = null;
        showToast('SUBSCRIPTION EXPIRED. LOGGING OUT…');
        setTimeout(() => {
            alert('Your key subscription has expired. Please enter a valid renewal key.');
            window.location.reload();
        }, 1200);
    }

    // Radar & Countdown Timer
    function updateCountdown(expireDateStr) {
        const expireTime = parseExpireTime(expireDateStr);
        if (!expireTime) {
            if (timeLeftDigits) timeLeftDigits.textContent = 'ACTIVE';
            if (radarProgressBar) radarProgressBar.style.strokeDashoffset = '150';
            return;
        }

        const now = Date.now();
        const diff = Math.max(0, expireTime - now);

        if (diff <= 0) {
            if (timeLeftDigits) timeLeftDigits.textContent = 'EXPIRED';
            if (radarProgressBar) radarProgressBar.style.strokeDashoffset = '690';
            return;
        }

        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const secs = Math.floor((diff % (1000 * 60)) / 1000);

        if (timeLeftDigits) {
            if (days > 0) {
                timeLeftDigits.textContent = `${days}D ${hours}H`;
            } else if (hours > 0) {
                timeLeftDigits.textContent = `${hours}H ${mins}M`;
            } else {
                timeLeftDigits.textContent = `${mins}M ${secs}S`;
            }
        }

        // Radar Circular Progress Animation (circumference approx 690)
        if (radarProgressBar) {
            const totalCycle = 30 * 86400 * 1000; // 30 days scale
            const percentRemaining = Math.min(1, diff / totalCycle);
            const offset = 690 - (percentRemaining * 500);
            radarProgressBar.style.strokeDashoffset = String(Math.round(offset));
        }
    }

    function startRealtimeCountdown(expireDateStr) {
        if (liveCountdownTimer) clearInterval(liveCountdownTimer);

        if (checkIsExpired(expireDateStr)) {
            handleExpiredSession();
            return;
        }

        updateCountdown(expireDateStr);

        liveCountdownTimer = setInterval(() => {
            if (checkIsExpired(expireDateStr)) {
                handleExpiredSession();
            } else {
                updateCountdown(expireDateStr);
            }
        }, 1000);
    }

    // Check for saved session
    try {
        const saved = localStorage.getItem('zrex_app_session');
        if (saved) {
            const sess = JSON.parse(saved);
            if (sess && sess.key && (sess.deep_link || sess.subscription_url)) {
                if (checkIsExpired(sess.expires_at)) {
                    localStorage.removeItem('zrex_app_session');
                    setTimeout(() => showToast('YOUR KEY HAS EXPIRED. ENTER NEW KEY.'), 600);
                } else {
                    renderApp(sess);
                }
            }
        }
    } catch (_) {}

    // Authentication Form Submit
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const keyVal = keyInput.value.trim().toUpperCase();
            if (!keyVal) return;

            btnUnlock.disabled = true;
            btnUnlock.textContent = 'AUTHENTICATING…';

            try {
                const response = await fetch('api/activate.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
                    body: JSON.stringify({
                        license_key: keyVal,
                        device_id: deviceId,
                        device_name: detectDevice()
                    })
                });

                const text = (await response.text()).trim();
                let data = null;
                try {
                    data = text ? JSON.parse(text) : null;
                } catch (_) {
                    throw new Error('Server returned invalid response');
                }

                if (!response.ok || !data || data.status !== 'success') {
                    throw new Error(data?.message || 'Authentication failed');
                }

                const deepLink = data.happ_deep_link || data.deep_link || ('happ://add/' + (data.subscription_url || ''));

                const sessionData = {
                    key: keyVal,
                    token: data.token || '',
                    expires_at: data.expires_at || '',
                    deep_link: deepLink,
                    subscription_url: data.subscription_url || '',
                    activated_at: new Date().toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' })
                };

                localStorage.setItem('zrex_app_session', JSON.stringify(sessionData));
                renderApp(sessionData);

                if (data.features) {
                    applyFeaturesState(data.features);
                }

            } catch (err) {
                alert(err.message || 'Connection error with license server');
            } finally {
                btnUnlock.disabled = false;
                btnUnlock.textContent = 'UNLOCK';
            }
        });
    }

    function renderApp(session) {
        currentSession = session;
        if (viewLogin) viewLogin.style.display = 'none';
        if (viewApp) viewApp.style.display = 'flex';
        if (bottomNav) bottomNav.style.display = 'flex';

        if (displayKey) displayKey.textContent = session.key;
        if (statActivated) statActivated.textContent = session.activated_at || 'TODAY';
        if (statExpires) statExpires.textContent = session.expires_at || 'ACTIVE';
        if (statDevice) statDevice.textContent = detectDevice();

        startRealtimeCountdown(session.expires_at);
        loadFeatures();
    }

    // Launch Happ VPN App with Key / Subscription
    if (btnAddSub) {
        btnAddSub.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            if (currentSession && (currentSession.deep_link || currentSession.subscription_url)) {
                showToast('LAUNCHING HAPP APP…');
                const link = currentSession.deep_link || ('happ://add/' + currentSession.subscription_url);
                window.location.href = link;
            }
        });
    }

    // Logout / Switch Key
    if (btnLogout) {
        btnLogout.addEventListener('click', () => {
            if (confirm('Do you want to log out of this key?')) {
                if (liveCountdownTimer) clearInterval(liveCountdownTimer);
                localStorage.removeItem('zrex_app_session');
                window.location.reload();
            }
        });
    }

    // ── FEATURES STATE & TOGGLES ──
    async function loadFeatures() {
        if (!currentSession) return;
        try {
            const res = await fetch('api/features.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ token: currentSession.token, key: currentSession.key })
            });
            const data = await res.json();
            if (data && data.features) {
                applyFeaturesState(data.features);
            }
        } catch (_) {}
        featuresLoaded = true;
    }

    function applyFeaturesState(f) {
        const switchMap = {
            'moco': 'sw-moco',
            'aimbot': 'sw-aimbot',
            'freeze_fire': 'sw-freeze_fire',
            'freeze_scope': 'sw-freeze_scope',
            'icewall': 'sw-icewall',
            'auto_revive': 'sw-auto_revive'
        };

        for (const [k, id] of Object.entries(switchMap)) {
            const el = document.getElementById(id);
            if (el && f[k] !== undefined) {
                el.checked = (parseInt(f[k], 10) === 1);
            }
        }

        // Aim Lag Master Switch
        const aimlagMaster = document.getElementById('sw-aimlag-master');
        if (aimlagMaster) {
            aimlagMaster.checked = (f.freeze_fire == 1 || f.freeze_scope == 1);
        }

        // Mark style active button
        if (f.marker !== undefined) {
            const targetVal = String(f.marker);
            document.querySelectorAll('.btn-mark').forEach(btn => {
                if (btn.dataset.val === targetVal) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            });
        }

        countActiveFeatures();
    }

    // Feature Switch Change Handlers
    document.querySelectorAll('.phantom-switch input[data-feat]').forEach(sw => {
        sw.addEventListener('change', async function() {
            const feat = this.dataset.feat;
            const val = this.checked ? '1' : '0';

            showToast(`${feat.toUpperCase()} → ${this.checked ? 'ON' : 'OFF'}`);

            if (feat === 'freeze_fire' || feat === 'freeze_scope') {
                const ff = document.getElementById('sw-freeze_fire')?.checked;
                const fs = document.getElementById('sw-freeze_scope')?.checked;
                const m = document.getElementById('sw-aimlag-master');
                if (m) m.checked = (ff || fs);
            }

            countActiveFeatures();

            try {
                if (currentSession) {
                    await fetch('api/features.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({
                            token: currentSession.token,
                            key: currentSession.key,
                            feature: feat,
                            value: val
                        })
                    });
                }
            } catch (_) {}
        });
    });

    // Aim Lag Master Switch
    const aimlagMaster = document.getElementById('sw-aimlag-master');
    if (aimlagMaster) {
        aimlagMaster.addEventListener('change', async function() {
            const isOn = this.checked;
            const ff = document.getElementById('sw-freeze_fire');
            const fs = document.getElementById('sw-freeze_scope');
            if (ff) ff.checked = isOn;
            if (fs) fs.checked = isOn;

            showToast(`AIM LAG → ${isOn ? 'ON' : 'OFF'}`);
            countActiveFeatures();

            try {
                if (currentSession) {
                    await fetch('api/features.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({
                            token: currentSession.token,
                            key: currentSession.key,
                            freeze_fire: isOn ? '1' : '0',
                            freeze_scope: isOn ? '1' : '0'
                        })
                    });
                }
            } catch (_) {}
        });
    }

    // Mark Style Buttons
    document.querySelectorAll('.btn-mark').forEach(btn => {
        btn.addEventListener('click', async function() {
            document.querySelectorAll('.btn-mark').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            const val = this.dataset.val;

            showToast(`MARKER → ${this.textContent.trim()}`);

            try {
                if (currentSession) {
                    await fetch('api/features.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({
                            token: currentSession.token,
                            key: currentSession.key,
                            marker: val
                        })
                    });
                }
            } catch (_) {}
        });
    });

    function countActiveFeatures() {
        let count = 0;
        const switches = ['sw-moco', 'sw-aimbot', 'sw-freeze_fire', 'sw-freeze_scope', 'sw-icewall', 'sw-auto_revive'];
        switches.forEach(id => {
            const el = document.getElementById(id);
            if (el && el.checked) count++;
        });
        if (featCounter) featCounter.textContent = `${Math.min(5, count)}/5`;
    }

})();
