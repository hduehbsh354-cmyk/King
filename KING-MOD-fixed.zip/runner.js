/**
 * ══════════════════════════════════════════════════════════════════
 * 𝙆𝙸𝙽𝙶 𝙼𝙾𝙳 - Zero-Dependency Local Runner (Node.js)
 * Serves the Web App & simulates the PHP API on localhost
 * ══════════════════════════════════════════════════════════════════
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 8080;
const PUBLIC_DIR = __dirname;
const DB_FILE = path.join(__dirname, 'data', 'keys.json');

// MIME types
const MIME_TYPES = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
};

// Database Helpers
function readDb() {
    try {
        if (!fs.existsSync(DB_FILE)) {
            return { keys: {} };
        }
        return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    } catch (e) {
        return { keys: {} };
    }
}

function writeDb(data) {
    try {
        const dir = path.dirname(DB_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error('Database write error:', e);
        return false;
    }
}

// Read JSON Body
function parseBody(req) {
    return new Promise((resolve) => {
        let data = '';
        req.on('data', chunk => { data += chunk; });
        req.on('end', () => {
            try {
                resolve(data ? JSON.parse(data) : {});
            } catch (_) {
                resolve({});
            }
        });
    });
}

function sendJson(res, statusCode, obj) {
    res.writeHead(statusCode, {
        'Content-Type': 'application/json; charset=utf-8',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Accept, Authorization',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Cache-Control': 'no-store, no-cache, must-revalidate'
    });
    res.end(JSON.stringify(obj));
}

// Server Request Handler
const server = http.createServer(async (req, res) => {
    const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    let pathname = parsedUrl.pathname;

    // CORS preflight
    if (req.method === 'OPTIONS') {
        res.writeHead(200, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type, Accept, Authorization',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
        });
        return res.end();
    }

    // ── API: /api/activate (or /api/activate.php) ──
    if (pathname === '/api/activate' || pathname === '/api/activate.php') {
        if (req.method !== 'POST') {
            return sendJson(res, 405, { status: 'error', message: 'Method Not Allowed' });
        }
        const body = await parseBody(req);
        const key = (body.license_key || '').trim().toUpperCase();
        const deviceId = (body.device_id || '').trim();
        const deviceName = (body.device_name || '').trim();

        if (!key) {
            return sendJson(res, 400, { status: 'error', message: 'Access key is required' });
        }

        const db = readDb();
        const item = db.keys[key];

        if (!item) {
            return sendJson(res, 400, { status: 'error', message: 'Invalid license key' });
        }

        if (item.status !== 'active') {
            return sendJson(res, 400, { status: 'error', message: 'License key is suspended or expired' });
        }

        // Expiry check
        if (item.expires_at) {
            const expTime = new Date(item.expires_at).getTime();
            if (!isNaN(expTime) && Date.now() >= expTime) {
                return sendJson(res, 400, { status: 'error', message: 'License key has expired' });
            }
        }

        // Device lock check
        if (item.device_id && item.device_id !== deviceId) {
            return sendJson(res, 400, { status: 'error', message: 'License key is bound to another device' });
        }

        const now = Date.now();
        const isFirst = !item.activated_at;
        const durationDays = parseInt(item.duration_days, 10) || 30;

        if (isFirst) {
            const expDate = new Date(now + durationDays * 86400 * 1000);
            item.activated_at = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
            item.expires_at = expDate.toISOString();
        }

        const token = crypto.randomBytes(16).toString('hex');
        item.token = token;
        item.device_id = deviceId;
        item.device_name = deviceName;

        const subUrl = item.subscription_url || `https://raxmods.store/sub/${encodeURIComponent(key)}`;
        const deepLink = item.happ_deep_link || `happ://add/${subUrl}`;

        if (!item.features) {
            item.features = { moco: 1, aimbot: 1, freeze_fire: 0, freeze_scope: 0, icewall: 0, auto_revive: 0, marker: '5' };
        }

        writeDb(db);

        return sendJson(res, 200, {
            status: 'success',
            token: token,
            expires_at: item.expires_at,
            subscription_url: subUrl,
            happ_deep_link: deepLink,
            features: item.features
        });
    }

    // ── API: /api/features (or /api/features.php) ──
    if (pathname === '/api/features' || pathname === '/api/features.php') {
        if (req.method !== 'POST') {
            return sendJson(res, 405, { ok: false, message: 'Method Not Allowed' });
        }
        const body = await parseBody(req);
        const token = (body.token || '').trim();
        const key = (body.key || '').trim().toUpperCase();

        const db = readDb();
        let targetKey = key;
        if (!targetKey && token) {
            for (const k in db.keys) {
                if (db.keys[k].token === token) {
                    targetKey = k;
                    break;
                }
            }
        }

        const item = db.keys[targetKey];
        if (!item) {
            return sendJson(res, 404, { ok: false, message: 'Key/Session not found' });
        }

        if (!item.features) item.features = {};

        // 1. Single Feature update
        if (body.feature !== undefined && body.value !== undefined) {
            item.features[body.feature] = parseInt(body.value, 10);
            writeDb(db);
            return sendJson(res, 200, { ok: true, message: 'Feature updated' });
        }

        // 2. Marker update
        if (body.marker !== undefined) {
            item.features.marker = String(body.marker);
            writeDb(db);
            return sendJson(res, 200, { ok: true, message: 'Marker updated' });
        }

        // 3. Aim Lag sub-options
        if (body.freeze_fire !== undefined || body.freeze_scope !== undefined) {
            if (body.freeze_fire !== undefined) item.features.freeze_fire = parseInt(body.freeze_fire, 10);
            if (body.freeze_scope !== undefined) item.features.freeze_scope = parseInt(body.freeze_scope, 10);
            writeDb(db);
            return sendJson(res, 200, { ok: true, message: 'Features updated' });
        }

        // Default query
        return sendJson(res, 200, { features: item.features });
    }

    // ── API: /api/admin (or /api/admin.php) ──
    if (pathname === '/api/admin' || pathname === '/api/admin.php') {
        const body = (req.method === 'POST') ? await parseBody(req) : {};
        const pass = body.password || parsedUrl.searchParams.get('password') || '';

        if (pass !== 'mohamed0112139') {
            return sendJson(res, 401, { ok: false, message: 'Unauthorized: Invalid password' });
        }

        const action = body.action || parsedUrl.searchParams.get('action') || 'list';
        const db = readDb();

        if (action === 'list') {
            return sendJson(res, 200, { ok: true, keys: Object.values(db.keys) });
        }

        if (action === 'create') {
            let keyName = (body.key || '').trim().toUpperCase();
            if (!keyName) {
                keyName = 'RAX-' + crypto.randomBytes(2).toString('hex').toUpperCase() + '-' + crypto.randomBytes(2).toString('hex').toUpperCase() + '-' + crypto.randomBytes(2).toString('hex').toUpperCase();
            }
            const days = parseInt(body.duration_days, 10) || 30;
            const subUrl = body.subscription_url || `https://raxmods.store/sub/${encodeURIComponent(keyName)}`;

            db.keys[keyName] = {
                key: keyName,
                status: 'active',
                created_at: new Date().toISOString(),
                activated_at: null,
                duration_days: days,
                expires_at: null,
                device_id: null,
                device_name: null,
                token: '',
                subscription_url: subUrl,
                happ_deep_link: `happ://add/${subUrl}`,
                features: { moco: 1, aimbot: 1, freeze_fire: 0, freeze_scope: 0, icewall: 0, auto_revive: 0, marker: '5' }
            };
            writeDb(db);
            return sendJson(res, 200, { ok: true, message: 'Key created', key: keyName, duration_days: days });
        }

        if (action === 'delete') {
            const targetKey = (body.key || '').trim().toUpperCase();
            if (db.keys[targetKey]) {
                delete db.keys[targetKey];
                writeDb(db);
                return sendJson(res, 200, { ok: true, message: 'Key deleted' });
            }
            return sendJson(res, 404, { ok: false, message: 'Key not found' });
        }

        if (action === 'unbind') {
            const targetKey = (body.key || '').trim().toUpperCase();
            if (db.keys[targetKey]) {
                db.keys[targetKey].device_id = null;
                db.keys[targetKey].device_name = null;
                db.keys[targetKey].token = '';
                writeDb(db);
                return sendJson(res, 200, { ok: true, message: 'Device unbound successfully' });
            }
            return sendJson(res, 404, { ok: false, message: 'Key not found' });
        }

        return sendJson(res, 400, { ok: false, message: 'Unknown action' });
    }

    // ── Subscription: /sub/<key-or-slug> ──
    if (pathname.startsWith('/sub/')) {
        const id = decodeURIComponent(pathname.slice(5).replace(/\/$/, ''));
        const fail = (code, msg) => { res.writeHead(code, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end(msg); };
        if (!/^[A-Za-z0-9_.\-]{1,100}$/.test(id)) return fail(404, 'Not Found');
        const keys = Object.values(readDb().keys || {});
        const row = keys.find(k => k.key === id) ||
            keys.find(k => (k.subscription_url || '').split('/').pop() === id);
        if (!row) return fail(404, 'Not Found');
        if ((row.status || 'active') !== 'active') return fail(403, 'Subscription suspended');
        if (!row.activated_at) return fail(403, 'Key not activated yet');
        let expTs = 0;
        if (row.expires_at) {
            const t = Date.parse(row.expires_at);
            if (!isNaN(t)) expTs = Math.floor(t / 1000);
        }
        if (expTs > 0 && Date.now() / 1000 >= expTs) return fail(403, 'Subscription expired');
        let file = path.join(__dirname, 'data', 'configs', id + '.txt');
        if (!fs.existsSync(file)) file = path.join(__dirname, 'data', 'configs.txt');
        let lines = [];
        try {
            lines = fs.readFileSync(file, 'utf8').split(/\r\n|\r|\n/).map(l => l.trim()).filter(l => l && !l.startsWith('#'));
        } catch (e) {}
        if (!lines.length) return fail(503, 'No configs available on server yet');
        res.writeHead(200, {
            'Content-Type': 'text/plain; charset=utf-8',
            'Cache-Control': 'no-store',
            'profile-title': 'KING MOD',
            'profile-update-interval': '1',
            'subscription-userinfo': `upload=0; download=0; total=0; expire=${expTs}`
        });
        return res.end(Buffer.from(lines.join('\n')).toString('base64'));
    }

    // ── Block private files from static serving ──
    if (/^\/(data|api\/.*\.php|config\.php|database\.php|runner\.js|README\.md|\.htaccess)/i.test(pathname) && !pathname.startsWith('/api/')) {
        res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
        return res.end('Access denied');
    }

    // ── Static Files Serving ──
    if (pathname === '/') pathname = '/index.html';
    if (pathname.endsWith('/')) pathname += 'index.html';

    let filePath = path.join(PUBLIC_DIR, pathname);
    if (!filePath.startsWith(PUBLIC_DIR)) {
        res.writeHead(403);
        return res.end('Access denied');
    }

    fs.stat(filePath, (err, stats) => {
        if (err || !stats.isFile()) {
            res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
            return res.end('404 Not Found');
        }

        const ext = path.extname(filePath).toLowerCase();
        const contentType = MIME_TYPES[ext] || 'application/octet-stream';

        res.writeHead(200, { 'Content-Type': contentType });
        const stream = fs.createReadStream(filePath);
        stream.pipe(res);
    });
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`\n======================================================`);
    console.log(`⚡ KING MOD LOCAL SERVER RUNNING!`);
    console.log(`🌐 Client App:  http://localhost:${PORT}`);
    console.log(`⚙️  Admin Panel: http://localhost:${PORT}/admin/`);
    console.log(`🔑 Demo Key:    RAX-VIP-ACTIVE`);
    console.log(`🔐 Admin Pass:  mohamed0112139`);
    console.log(`======================================================\n`);
});
