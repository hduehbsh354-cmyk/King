import socket
import unittest
from unittest import mock
from app.scanner.engine import run_scan
from app.scanner.ssrf import TargetNotAllowed


class FakeDns:
    def query(self, name, rtype):
        return {("example.com", "MX"): ["10 mail.example.com."]}.get((name, rtype), [])


class EngineTests(unittest.TestCase):
    def test_unreachable_site_degrades_gracefully(self):
        with mock.patch.object(socket, "create_connection", side_effect=ConnectionRefusedError):
            r = run_scan("https://Example.com/", dns=FakeDns(), resolver=lambda h, p: ["93.184.216.34"])
        ids = {f["check_id"] for f in r["findings"]}
        self.assertIn("site.unreachable", ids)
        self.assertIn("tls.unavailable", ids)
        self.assertIn("dns.spf_missing", ids)       # فحوصات DNS تعمل رغم فشل الموقع
        self.assertEqual(r["hostname"], "example.com")
        self.assertIn(r["grade"], "ABCDF")
        self.assertEqual(sum(r["counts"].values()), len(r["findings"]))

    def test_private_target_rejected_before_any_request(self):
        with mock.patch.object(socket, "create_connection") as cc:
            with self.assertRaises(TargetNotAllowed):
                run_scan("example.com", dns=FakeDns(), resolver=lambda h, p: ["10.1.2.3"])
            cc.assert_not_called()
        with self.assertRaises(TargetNotAllowed):
            run_scan("169.254.169.254")


if __name__ == "__main__":
    unittest.main()
