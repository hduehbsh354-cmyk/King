"""اختبار تكاملي على خادم محلي. يعطّل حاجز IP العام داخل الاختبار فقط."""
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from unittest import mock

from app.scanner import ssrf, engine
from app.scanner.http_client import fetch
from app.scanner.ssrf import TargetNotAllowed

HOST = "site.test.example"


class H(BaseHTTPRequestHandler):
    server_version = "Apache/2.2.15"
    sys_version = ""
    def log_message(self, *a): pass

    def do_GET(self):
        if self.path == "/out":
            self.send_response(302); self.send_header("Location", "http://evil.com/"); self.end_headers(); return
        if self.path == "/in":
            self.send_response(302); self.send_header("Location", "/final"); self.end_headers(); return
        self.send_response(200)
        self.send_header("Set-Cookie", "sessionid=1; Path=/")
        self.send_header("Content-Type", "text/html"); self.end_headers()
        self.wfile.write(b"<html>ok</html>")


class Integration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = HTTPServer(("127.0.0.1", 8080), H)
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.patches = [mock.patch.object(ssrf, "is_public_ip", lambda ip: True),
                       mock.patch.object(ssrf, "ALLOWED_PORTS", {80, 443, 8080, 8443})]
        for p in cls.patches: p.start()
        cls.res = lambda self, h, p: ["127.0.0.1"]

    @classmethod
    def tearDownClass(cls):
        for p in cls.patches: p.stop()
        cls.srv.shutdown()

    def test_fetch_and_redirects(self):
        r = fetch(f"http://{HOST}:8080/", scope_domain=HOST, resolver=self.res)
        self.assertEqual((r.status, r.header("server").strip()), (200, "Apache/2.2.15"))
        r = fetch(f"http://{HOST}:8080/in", scope_domain=HOST, resolver=self.res)
        self.assertTrue(r.url.endswith("/final") and r.redirects)
        r = fetch(f"http://{HOST}:8080/out", scope_domain=HOST, resolver=self.res)
        self.assertEqual(r.status, 302)  # لم يُتَّبع لأنه خارج النطاق
        self.assertIn("evil.com", r.header("location"))

    def test_out_of_scope_refused(self):
        with self.assertRaises(TargetNotAllowed):
            fetch("http://evil.com:8080/", scope_domain=HOST, resolver=self.res)

    def test_private_resolution_refused_when_guard_on(self):
        with mock.patch.object(ssrf, "is_public_ip", lambda ip: ip != "127.0.0.1"):
            with self.assertRaises(TargetNotAllowed):
                fetch(f"http://{HOST}:8080/", scope_domain=HOST, resolver=self.res)


if __name__ == "__main__":
    unittest.main()
