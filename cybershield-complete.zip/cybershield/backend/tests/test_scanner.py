import time
import unittest
from app.scanner import ssrf
from app.scanner.ssrf import TargetNotAllowed, normalize_domain, resolve_public, validate_url
from app.scanner.findings import Finding, Severity, dedupe, summarize
from app.scanner.http_client import HttpResponse
from app.scanner.checks.headers import analyze_headers
from app.scanner.checks.cookies import analyze_cookies
from app.scanner.checks.fingerprint import analyze_fingerprint
from app.scanner.checks.dns_checks import check_dns
from app.scanner import ownership
from app.services.compare import compare_scans
from app import security
from app.ratelimit import MemoryLimiter


def R(headers, url="https://example.com/", body=b""):
    return HttpResponse(url, 200, headers, body, "93.184.216.34", True)


class FakeDns:
    def __init__(self, data): self.data = data
    def query(self, name, rtype): return self.data.get((name, rtype), [])


class SSRF(unittest.TestCase):
    def test_normalize(self):
        self.assertEqual(normalize_domain("HTTPS://Example.com/path?x=1"), "example.com")
        self.assertEqual(normalize_domain("example.com:8443"), "example.com")
        for bad in ["", "127.0.0.1", "http://169.254.169.254/", "localhost", "foo.local",
                    "http://user:pw@example.com", "[::1]", "a_b.com", "-x.com", "nodots"]:
            with self.assertRaises(TargetNotAllowed, msg=bad):
                normalize_domain(bad)

    def test_private_ips_blocked(self):
        for ip in ["127.0.0.1", "10.0.0.5", "192.168.1.1", "172.16.0.1", "169.254.169.254",
                   "100.64.0.1", "::1", "fe80::1", "::ffff:127.0.0.1", "0.0.0.0", "224.0.0.1"]:
            self.assertFalse(ssrf.is_public_ip(ip), ip)
        self.assertTrue(ssrf.is_public_ip("93.184.216.34"))

    def test_resolve_rejects_if_any_private(self):
        with self.assertRaises(TargetNotAllowed):
            resolve_public("a.com", 443, lambda h, p: ["93.184.216.34", "10.0.0.1"])
        self.assertEqual(resolve_public("a.com", 443, lambda h, p: ["93.184.216.34"]), ["93.184.216.34"])

    def test_scope_and_ports(self):
        self.assertEqual(validate_url("https://www.example.com/x", "example.com")[1], "www.example.com")
        for bad in ["https://evil.com/", "https://example.com.evil.com/", "ftp://example.com/",
                    "https://example.com:22/", "https://a@example.com/", "https://notexample.com/"]:
            with self.assertRaises(TargetNotAllowed, msg=bad):
                validate_url(bad, "example.com")


class Headers(unittest.TestCase):
    def ids(self, fs): return {f.check_id for f in fs}

    def test_all_missing(self):
        ids = self.ids(analyze_headers(R([])))
        for x in ["hsts_missing", "csp_missing", "clickjacking", "nosniff_missing", "referrer_policy_missing"]:
            self.assertIn("headers." + x, ids)

    def test_good_config(self):
        h = [("Strict-Transport-Security", "max-age=31536000; includeSubDomains"),
             ("Content-Security-Policy", "default-src 'self'; frame-ancestors 'none'"),
             ("X-Content-Type-Options", "nosniff"), ("Referrer-Policy", "no-referrer"),
             ("Permissions-Policy", "camera=()")]
        self.assertEqual(analyze_headers(R(h)), [])

    def test_weak_csp_and_hsts(self):
        h = [("Strict-Transport-Security", "max-age=100"),
             ("Content-Security-Policy", "default-src 'self'; script-src 'unsafe-inline' 'unsafe-eval' *")]
        ids = self.ids(analyze_headers(R(h)))
        self.assertTrue({"headers.hsts_short", "headers.csp_unsafe_inline",
                         "headers.csp_unsafe_eval", "headers.csp_wildcard"} <= ids)

    def test_no_hsts_finding_on_http(self):
        self.assertNotIn("headers.hsts_missing", self.ids(analyze_headers(R([], url="http://example.com/"))))


class Cookies(unittest.TestCase):
    def test_flags(self):
        fs = analyze_cookies(R([("Set-Cookie", "sessionid=abc; Path=/"),
                                ("Set-Cookie", "pref=1; Secure; HttpOnly; SameSite=Lax"),
                                ("Set-Cookie", "t=1; SameSite=None; HttpOnly")]))
        by = {(f.check_id, f.location): f.severity for f in fs}
        self.assertEqual(by[("cookies.no_secure", "Cookie: sessionid")], Severity.MEDIUM)
        self.assertEqual(by[("cookies.no_httponly", "Cookie: sessionid")], Severity.MEDIUM)
        self.assertNotIn(("cookies.no_secure", "Cookie: pref"), by)
        self.assertIn(("cookies.samesite_none_insecure", "Cookie: t"), by)


class Fingerprint(unittest.TestCase):
    def test_detect(self):
        r = R([("Server", "Apache/2.2.15 (CentOS)"), ("X-Powered-By", "PHP/7.4.33")],
              body=b'<html><meta name="generator" content="WordPress 6.4.2"></html>')
        ids = {f.check_id for f in analyze_fingerprint(r)}
        self.assertTrue({"disclosure.apache", "eol.apache", "disclosure.php", "eol.php",
                         "disclosure.wordpress"} <= ids)

    def test_supported_not_eol(self):
        ids = {f.check_id for f in analyze_fingerprint(R([("Server", "Apache/2.4.58")]))}
        self.assertNotIn("eol.apache", ids)

    def test_no_version_no_finding(self):
        self.assertEqual(analyze_fingerprint(R([("Server", "nginx")])), [])


class Dns(unittest.TestCase):
    def test_missing_all(self):
        d = FakeDns({("example.com", "MX"): ["10 mail.example.com."]})
        fs = {f.check_id: f.severity for f in check_dns("example.com", d)}
        self.assertEqual(fs["dns.spf_missing"], Severity.MEDIUM)
        self.assertEqual(fs["dns.dmarc_missing"], Severity.MEDIUM)
        self.assertIn("dns.caa_missing", fs)

    def test_no_mail_lower_severity_and_null_mx(self):
        d = FakeDns({("example.com", "MX"): ["0 ."]})
        fs = {f.check_id: f.severity for f in check_dns("example.com", d)}
        self.assertEqual(fs["dns.spf_missing"], Severity.LOW)

    def test_spf_plus_all_and_dmarc_none(self):
        d = FakeDns({("example.com", "TXT"): ["v=spf1 +all"],
                     ("_dmarc.example.com", "TXT"): ["v=DMARC1; p=none"],
                     ("example.com", "CAA"): ['0 issue "letsencrypt.org"']})
        fs = {f.check_id: f.severity for f in check_dns("example.com", d)}
        self.assertEqual(fs["dns.spf_allow_all"], Severity.HIGH)
        self.assertEqual(fs["dns.dmarc_none"], Severity.LOW)
        self.assertNotIn("dns.caa_missing", fs)


class Ownership(unittest.TestCase):
    def test_dns_verify(self):
        t = ownership.generate_token()
        self.assertTrue(t.startswith("cybershield-verify="))
        ok = FakeDns({("_cybershield.example.com", "TXT"): [t]})
        bad = FakeDns({("_cybershield.example.com", "TXT"): ["cybershield-verify=other"]})
        self.assertTrue(ownership.verify_dns("example.com", t, ok))
        self.assertFalse(ownership.verify_dns("example.com", t, bad))
        self.assertNotEqual(t, ownership.generate_token())


class Scoring(unittest.TestCase):
    def mk(self, sev, cid="x", loc="l"):
        return Finding(cid, "t", sev, "c", "d", loc, "i", "r")

    def test_summary_and_dedupe(self):
        fs = dedupe([self.mk(Severity.HIGH), self.mk(Severity.HIGH), self.mk(Severity.LOW, "y")])
        self.assertEqual(len(fs), 2)
        s = summarize(fs)
        self.assertEqual((s["score"], s["grade"]), (82, "B"))
        self.assertEqual(s["counts"]["high"], 1)
        self.assertEqual(summarize([self.mk(Severity.CRITICAL, str(i)) for i in range(5)])["score"], 0)


class Compare(unittest.TestCase):
    def test_diff(self):
        f = lambda c: {"check_id": c, "location": "l"}
        r = compare_scans({"findings": [f("a"), f("b")], "score": 70},
                          {"findings": [f("b"), f("c")], "score": 80})
        self.assertEqual([x["check_id"] for x in r["new"]], ["c"])
        self.assertEqual([x["check_id"] for x in r["resolved"]], ["a"])
        self.assertEqual(r["score_delta"], 10)


class Sec(unittest.TestCase):
    def test_password(self):
        h = security.hash_password("Str0ngPassw0rd")
        self.assertTrue(security.verify_password("Str0ngPassw0rd", h))
        self.assertFalse(security.verify_password("wrong", h))
        self.assertFalse(security.verify_password("x", "garbage"))
        self.assertTrue(security.password_problems("abc"))
        self.assertFalse(security.password_problems("Str0ngPassw0rd"))

    def test_jwt(self):
        k = "k" * 40
        t = security.create_access_token(k, 7, "user", 15)
        self.assertEqual(security.decode_access_token(k, t)["sub"], "7")
        self.assertIsNone(security.decode_access_token("other" * 10, t))
        self.assertIsNone(security.decode_access_token(k, "bad.token.x"))
        self.assertIsNone(security.decode_access_token(k, security.create_access_token(k, 1, "u", -1)))

    def test_ratelimit(self):
        l = MemoryLimiter()
        self.assertTrue(all(l.hit("a", 3, 60)[0] for _ in range(3)))
        ok, retry = l.hit("a", 3, 60)
        self.assertFalse(ok); self.assertGreater(retry, 0)
        self.assertTrue(l.hit("b", 3, 60)[0])


if __name__ == "__main__":
    unittest.main()
