from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict, EmailStr, Field


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)
    full_name: str = Field(default="", max_length=120)


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(max_length=128)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    email: str
    full_name: str
    role: str
    created_at: datetime
    last_login_at: Optional[datetime] = None


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class ProfileIn(BaseModel):
    full_name: str = Field(max_length=120)


class ChangePasswordIn(BaseModel):
    current_password: str = Field(max_length=128)
    new_password: str = Field(max_length=128)


class ForgotIn(BaseModel):
    email: EmailStr


class ResetIn(BaseModel):
    token: str = Field(max_length=200)
    new_password: str = Field(max_length=128)


class SessionOut(BaseModel):
    id: int
    user_agent: str
    ip: str
    created_at: datetime
    last_used_at: datetime
    current: bool = False


class DomainIn(BaseModel):
    hostname: str = Field(max_length=300)


class DomainOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    hostname: str
    verified_at: Optional[datetime] = None
    verified_method: Optional[str] = None
    created_at: datetime
    verification: Optional[dict] = None


class ScanIn(BaseModel):
    domain_id: int
    authorization_confirmed: bool = False


class FindingOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    check_id: str
    title: str
    severity: str
    category: str
    description: str
    location: str
    impact: str
    recommendation: str
    reference: str


class ScanOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    domain_id: int
    hostname: str = ""
    status: str
    step: str
    progress: int
    score: Optional[int] = None
    grade: Optional[str] = None
    counts: Optional[dict] = None
    error: str = ""
    created_at: datetime
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None


class ScanDetailOut(ScanOut):
    details: Optional[dict] = None
    findings: list[FindingOut] = []
