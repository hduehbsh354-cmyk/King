"""عميل HTTP آمن: يتحقق من SSRF في كل قفزة، ويثبّت IP المحلول، ويقيّد الحجم والتحويلات."""
from __future__ import annotations
import http.client
import socket
import ssl
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import urljoin, urlsplit

from .ssrf import Resolver, TargetNotAllowed, in_scope, resolve_public, validate_url

USER_AGENT = "CyberShieldPro-Scanner/1.0 (authorized passive security scan)"


@dataclass
class HttpResponse:
    url: str
    status: int
    headers: list
    body: bytes
    ip: str
    tls_verified: Optional[bool] = None
    tls_error: Optional[str] = None
    redirects: list = field(default_factory=list)

    def header(self, name: str) -> Optional[str]:
        n = name.lower()
        for k, v in self.headers:
            if k.lower() == n:
                return v
        return None

    def header_all(self, name: str) -> list:
        n = name.lower()
        return [v for k, v in self.headers if k.lower() == n]

    @property
    def text(self) -> str:
        return self.body.decode("utf-8", errors="replace")


class _PinnedHTTP(http.client.HTTPConnection):
    def __init__(self, host, port, ip, timeout):
        super().__init__(host, port, timeout=timeout)
        self._ip = ip

    def connect(self):
        self.sock = socket.create_connection((self._ip, self.port), self.timeout)


class _PinnedHTTPS(http.client.HTTPSConnection):
    def __init__(self, host, port, ip, timeout, context):
        super().__init__(host, port, timeout=timeout, context=context)
        self._ip = ip
        self._ctx = context

    def connect(self):
        sock = socket.create_connection((self._ip, self.port), self.timeout)
        self.sock = self._ctx.wrap_socket(sock, server_hostname=self.host)


def _unverified_ctx() -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _single(scheme, host, port, path, ip, timeout, max_bytes, method):
    tls_verified, tls_error = None, None
    attempts = [ssl.create_default_context(), _unverified_ctx()] if scheme == "https" else [None]
    last_exc = None
    for i, ctx in enumerate(attempts):
        conn = (_PinnedHTTPS(host, port, ip, timeout, ctx) if scheme == "https"
                else _PinnedHTTP(host, port, ip, timeout))
        try:
            conn.request(method, path or "/", headers={
                "User-Agent": USER_AGENT, "Accept": "*/*", "Accept-Encoding": "identity",
                "Connection": "close"})
            r = conn.getresponse()
            body = r.read(max_bytes) if method != "HEAD" else b""
            if scheme == "https":
                tls_verified = (i == 0)
            return r.status, r.getheaders(), body, tls_verified, tls_error
        except ssl.SSLCertVerificationError as e:
            tls_error = e.verify_message or str(e)
            last_exc = e
        finally:
            conn.close()
    raise last_exc  # type: ignore[misc]


def fetch(url: str, *, scope_domain: str, resolver: Optional[Resolver] = None,
          follow: bool = True, max_redirects: int = 3, timeout: float = 8.0,
          max_bytes: int = 256 * 1024, method: str = "GET") -> HttpResponse:
    """يجلب الرابط ضمن النطاق المصرّح. التحويلات خارج النطاق لا تُتّبع."""
    current, redirects = url, []
    for _ in range(max_redirects + 1):
        scheme, host, port = validate_url(current, scope_domain)
        ips = resolve_public(host, port, resolver)
        parts = urlsplit(current)
        path = parts.path or "/"
        if parts.query:
            path += "?" + parts.query
        status, headers, body, tv, te = _single(scheme, host, port, path, ips[0],
                                                timeout, max_bytes, method)
        resp = HttpResponse(current, status, headers, body, ips[0], tv, te, list(redirects))
        loc = resp.header("location")
        if follow and 300 <= status < 400 and loc:
            nxt = urljoin(current, loc)
            h = (urlsplit(nxt).hostname or "")
            if in_scope(h, scope_domain):
                redirects.append(nxt)
                current = nxt
                continue
        return resp
    return resp
