"""اكتشاف إصدارات البرمجيات المكشوفة (من الترويسات ووسم generator فقط)."""
import re
from ..findings import Finding, Severity as S

CAT = "Information Disclosure"
REF = "https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/01-Information_Gathering/02-Fingerprint_Web_Server"
TOKEN = re.compile(r"([A-Za-z][\w\-\.]*)/(\d+(?:\.\d+){0,3})")
META = re.compile(r"<meta[^>]+name=[\"']generator[\"'][^>]*content=[\"']([^\"']+)[\"']|"
                  r"<meta[^>]+content=[\"']([^\"']+)[\"'][^>]*name=[\"']generator[\"']", re.I)
# أدنى إصدار مدعوم أمنياً. حدّث الجدول دورياً.
MIN_SUPPORTED = {"php": (8, 2), "apache": (2, 4), "tomcat": (9, 0)}


def _vt(v): return tuple(int(x) for x in v.split(".")[:3])


def _norm(name: str) -> str:
    n = name.lower()
    return "apache" if n.startswith("apache") else "tomcat" if "tomcat" in n else n


def extract(headers_get, body: str) -> list:
    """يعيد [(product, version, source)]."""
    found = []
    for h in ("server", "x-powered-by", "x-aspnet-version", "x-aspnetmvc-version", "x-generator"):
        v = headers_get(h)
        if not v:
            continue
        toks = TOKEN.findall(v)
        if toks:
            found += [(n, ver, f"Header: {h}") for n, ver in toks]
        elif h.startswith("x-asp"):
            found.append(("ASP.NET", v.strip(), f"Header: {h}"))
    for m in META.finditer(body[:200_000]):
        g = m.group(1) or m.group(2)
        mm = re.match(r"([A-Za-z][\w\s\.\-]*?)\s+v?(\d+(?:\.\d+){1,3})", g)
        if mm:
            found.append((mm.group(1).strip(), mm.group(2), "HTML meta generator"))
    return found


def analyze_fingerprint(resp) -> list:
    out = []
    for name, ver, src in extract(resp.header, resp.text):
        out.append(Finding(f"disclosure.{_norm(name)}", f"Software version disclosed: {name} {ver}",
            S.LOW, CAT, f"الموقع يكشف عن استخدام {name} بالإصدار {ver}.", src,
            "يسهّل على المهاجم البحث عن ثغرات معروفة تخص هذا الإصدار تحديداً.",
            "أخفِ رقم الإصدار (مثل ServerTokens Prod / server_tokens off / expose_php=Off) وحدّث البرنامج.",
            REF))
        mn = MIN_SUPPORTED.get(_norm(name))
        try:
            if mn and _vt(ver) < mn:
                out.append(Finding(f"eol.{_norm(name)}", f"Outdated/unsupported {name} version",
                    S.MEDIUM, CAT,
                    f"الإصدار {ver} أقدم من أقل إصدار مدعوم أمنياً ({'.'.join(map(str, mn))}). "
                    "ملاحظة: النتيجة مبنية على ما يعلنه الخادم وقد لا تعكس ترقيعات الموزّع.",
                    src, "إصدارات منتهية الدعم لا تتلقى إصلاحات أمنية.",
                    "رقّ إلى إصدار مدعوم وتحقق من نشرات الأمان الرسمية.", REF))
        except ValueError:
            pass
    return out
