"""فحص إعدادات Cookies من ترويسات Set-Cookie."""
from ..findings import Finding, Severity as S
from ..http_client import HttpResponse

CAT = "Cookies"
REF = "https://developer.mozilla.org/en-US/docs/Web/HTTP/Cookies#security"
SESSION_HINTS = ("sess", "sid", "auth", "token", "jwt", "login", "user")


def parse_set_cookie(raw: str) -> dict:
    parts = [p.strip() for p in raw.split(";")]
    name = parts[0].split("=", 1)[0].strip()
    attrs = {}
    for p in parts[1:]:
        k, _, v = p.partition("=")
        attrs[k.strip().lower()] = v.strip()
    return {"name": name, "attrs": attrs}


def analyze_cookies(resp: HttpResponse) -> list:
    out, https = [], resp.url.startswith("https://")
    for raw in resp.header_all("set-cookie"):
        c = parse_set_cookie(raw)
        name, a = c["name"], c["attrs"]
        sensitive = any(h in name.lower() for h in SESSION_HINTS)
        loc = f"Cookie: {name}"

        def add(cid, title, sev, desc, impact, rec):
            out.append(Finding(f"cookies.{cid}", title, sev, CAT, desc, loc, impact, rec, REF))

        if https and "secure" not in a:
            add("no_secure", "Cookie without Secure flag", S.MEDIUM if sensitive else S.LOW,
                f"الكوكي «{name}» لا يحمل الخاصية Secure.",
                "قد يُرسل الكوكي عبر اتصال HTTP غير مشفّر ويمكن التقاطه.",
                "أضف الخاصية Secure.")
        if "httponly" not in a:
            add("no_httponly", "Cookie without HttpOnly flag", S.MEDIUM if sensitive else S.LOW,
                f"الكوكي «{name}» لا يحمل الخاصية HttpOnly.",
                "يمكن لأي سكربت (مثلاً عبر XSS) قراءة الكوكي.",
                "أضف الخاصية HttpOnly للكوكيز التي لا تحتاجها JavaScript.")
        ss = a.get("samesite", "").lower()
        if not ss:
            add("no_samesite", "Cookie without SameSite attribute", S.LOW,
                f"الكوكي «{name}» لا يحدد SameSite.",
                "يزيد التعرض لهجمات CSRF حسب سلوك المتصفح الافتراضي.",
                "أضف SameSite=Lax أو Strict.")
        elif ss == "none" and "secure" not in a:
            add("samesite_none_insecure", "SameSite=None without Secure", S.MEDIUM,
                f"الكوكي «{name}» يستخدم SameSite=None دون Secure.",
                "ترفض المتصفحات الحديثة هذا الكوكي، ويكشف سوء إعداد.",
                "أضف Secure أو غيّر SameSite.")
    return out
