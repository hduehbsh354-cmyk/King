"""فحص شهادة SSL/TLS والبروتوكولات (اتصال عادي بدون أي استغلال)."""
import socket
import ssl
import time
from ..findings import Finding, Severity as S

CAT = "SSL/TLS"
REF = "https://developer.mozilla.org/en-US/docs/Web/Security/Transport_Layer_Security"


def _f(cid, title, sev, desc, loc, impact, rec):
    return Finding(f"tls.{cid}", title, sev, CAT, desc, loc, impact, rec, REF)


def _flatten(name_tuples) -> str:
    return ", ".join(f"{k}={v}" for rdn in name_tuples for k, v in rdn)


def _legacy_protocols(host, ip, port, timeout) -> list:
    accepted = []
    for ver in (ssl.TLSVersion.TLSv1, ssl.TLSVersion.TLSv1_1):
        try:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
            ctx.minimum_version = ctx.maximum_version = ver
            ctx.set_ciphers("ALL:@SECLEVEL=0")
            with socket.create_connection((ip, port), timeout) as s:
                with ctx.wrap_socket(s, server_hostname=host):
                    accepted.append(ver.name.replace("_", "."))
        except (ssl.SSLError, OSError, ValueError):
            continue
    return accepted


def check_tls(host: str, ip: str, port: int = 443, timeout: float = 8.0):
    """يعيد (findings, info)."""
    out, info, loc = [], {}, f"{host}:{port}"
    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((ip, port), timeout) as s:
            with ctx.wrap_socket(s, server_hostname=host) as ss:
                cert, info["protocol"] = ss.getpeercert(), ss.version()
                info["cipher"] = (ss.cipher() or ("",))[0]
    except ssl.SSLCertVerificationError as e:
        msg = (e.verify_message or str(e)).lower()
        info["verify_error"] = e.verify_message or str(e)
        if "expired" in msg:
            out.append(_f("expired", "SSL certificate expired", S.HIGH,
                "شهادة SSL منتهية الصلاحية.", loc,
                "تظهر للزوار تحذيرات أمان ويفقد المتصفح الثقة بالاتصال.",
                "جدّد الشهادة وفعّل التجديد التلقائي (مثل Let's Encrypt/ACME)."))
        elif "host" in msg and "match" in msg:
            out.append(_f("hostname_mismatch", "Certificate hostname mismatch", S.HIGH,
                "اسم النطاق غير مطابق للشهادة.", loc,
                "لا يمكن للمتصفح التحقق من هوية الخادم.",
                "أصدر شهادة تغطي هذا النطاق (SAN)."))
        elif "self" in msg and "signed" in msg:
            out.append(_f("self_signed", "Self-signed certificate", S.HIGH,
                "الشهادة موقّعة ذاتياً وغير موثوقة.", loc,
                "يمكن انتحال الخادم، ويعتاد المستخدمون تجاهل التحذيرات.",
                "استخدم شهادة من جهة موثوقة."))
        else:
            out.append(_f("untrusted", "Certificate not trusted", S.MEDIUM,
                f"فشل التحقق من الشهادة: {e.verify_message}.", loc,
                "قد تظهر تحذيرات أمان أو تفشل بعض العملاء بالاتصال.",
                "تأكد من تضمين سلسلة الشهادات الوسيطة كاملة."))
        try:  # اتصال بدون تحقق لقراءة البروتوكول فقط
            uctx = ssl.create_default_context()
            uctx.check_hostname, uctx.verify_mode = False, ssl.CERT_NONE
            with socket.create_connection((ip, port), timeout) as s:
                with uctx.wrap_socket(s, server_hostname=host) as ss:
                    info["protocol"] = ss.version()
        except (ssl.SSLError, OSError):
            pass
        cert = None
    except (ssl.SSLError, OSError) as e:
        out.append(_f("unavailable", "HTTPS not available", S.HIGH,
            f"تعذّر إتمام اتصال TLS على المنفذ {port} ({type(e).__name__}).", loc,
            "البيانات تنتقل دون تشفير أو أن الموقع غير متاح عبر HTTPS.",
            "فعّل HTTPS بشهادة صالحة ووجّه كل الزيارات إليه."))
        return out, info

    if cert:
        na = ssl.cert_time_to_seconds(cert["notAfter"])
        days = int((na - time.time()) // 86400)
        info.update(days_left=days, not_after=cert["notAfter"],
                    issuer=_flatten(cert.get("issuer", ())),
                    subject=_flatten(cert.get("subject", ())))
        if 0 <= days < 30:
            out.append(_f("expiring", "Certificate expires soon",
                S.HIGH if days < 7 else S.MEDIUM,
                f"تنتهي الشهادة خلال {days} يوم.", loc,
                "انتهاء الشهادة يُسقط الموقع ويظهر تحذيراً للزوار.",
                "جدّد الشهادة الآن وفعّل التجديد التلقائي."))
    if info.get("protocol") in ("TLSv1", "TLSv1.1", "SSLv3"):
        out.append(_f("weak_negotiated", "Weak TLS protocol negotiated", S.HIGH,
            f"تم التفاوض على {info['protocol']}.", loc,
            "بروتوكولات قديمة معرّضة لهجمات معروفة.", "اقصر الدعم على TLS 1.2 و1.3."))
    legacy = _legacy_protocols(host, ip, port, timeout)
    info["legacy_protocols"] = legacy
    if legacy:
        out.append(_f("legacy_protocols", "Deprecated TLS versions enabled", S.MEDIUM,
            "الخادم يقبل: " + ", ".join(legacy) + ".", loc,
            "هذه الإصدارات مهجورة (RFC 8996) وفيها نقاط ضعف.",
            "عطّل TLS 1.0 و1.1 وأبقِ 1.2 و1.3."))
    return out, info
