from ..findings import Finding, Severity as S
from ..http_client import fetch


def check_security_txt(host, resolver=None):
    loc = f"https://{host}/.well-known/security.txt"
    try:
        r = fetch(loc, scope_domain=host, resolver=resolver, max_bytes=16384)
        if r.status == 200 and "contact:" in r.text.lower():
            return []
    except Exception:
        pass
    return [Finding("misc.security_txt_missing", "Missing security.txt", S.INFO,
        "Web Security", "لا يوجد ملف security.txt لتلقّي البلاغات الأمنية.", loc,
        "قد يصعب على الباحثين الأمنيين الإبلاغ عن مشكلة يكتشفونها.",
        "أنشئ /.well-known/security.txt يحتوي Contact وExpires.",
        "https://www.rfc-editor.org/rfc/rfc9116")]
