from ..findings import Finding, Severity as S
from ..http_client import fetch


def check_http_redirect(host, resolver=None):
    loc = f"http://{host}/"
    try:
        r = fetch(loc, scope_domain=host, resolver=resolver, follow=False, method="GET")
    except Exception:
        return []  # المنفذ 80 مغلق: لا مشكلة
    target = r.header("location") or ""
    if 300 <= r.status < 400 and target.startswith("https://"):
        return []
    return [Finding("https.no_redirect", "HTTP is not redirected to HTTPS", S.MEDIUM, "SSL/TLS",
        "الموقع يستجيب عبر HTTP دون تحويل إلى HTTPS.", loc,
        "يمكن اعتراض أو تعديل حركة المرور غير المشفرة.",
        "أضف تحويل 301 دائماً من HTTP إلى HTTPS.",
        "https://developer.mozilla.org/en-US/docs/Web/Security/Transport_Layer_Security")]
