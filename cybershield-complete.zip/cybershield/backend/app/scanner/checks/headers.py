"""فحص رؤوس HTTP الأمنية (سلبي: يقرأ الرد فقط)."""
import re
from ..findings import Finding, Severity as S
from ..http_client import HttpResponse
from ._ref import MDN, OWASP_HEADERS

CAT = "HTTP Security Headers"


def _f(cid, title, sev, desc, loc, impact, rec, ref):
    return Finding(f"headers.{cid}", title, sev, CAT, desc, loc, impact, rec, ref)


def _csp_directives(csp: str) -> dict:
    out = {}
    for part in csp.split(";"):
        bits = part.strip().split()
        if bits:
            out.setdefault(bits[0].lower(), bits[1:])
    return out


def analyze_headers(resp: HttpResponse) -> list:
    out, is_https = [], resp.url.startswith("https://")
    loc = resp.url

    hsts = resp.header("strict-transport-security")
    if is_https:
        if not hsts:
            out.append(_f("hsts_missing", "Missing HSTS header", S.MEDIUM,
                "الموقع لا يرسل ترويسة Strict-Transport-Security.", loc,
                "يمكن للمهاجم على الشبكة إجبار المتصفح على الاتصال عبر HTTP (SSL stripping).",
                "أضف: Strict-Transport-Security: max-age=31536000; includeSubDomains",
                MDN + "Strict-Transport-Security"))
        else:
            m = re.search(r"max-age\s*=\s*(\d+)", hsts, re.I)
            age = int(m.group(1)) if m else 0
            if age < 15552000:
                out.append(_f("hsts_short", "HSTS max-age is too short", S.LOW,
                    f"قيمة max-age الحالية {age} ثانية وهي أقل من 6 أشهر.", loc,
                    "حماية HSTS تنتهي سريعاً وتترك نافذة للهجمات.",
                    "ارفع max-age إلى 31536000 (سنة) على الأقل.", MDN + "Strict-Transport-Security"))
            if "includesubdomains" not in hsts.lower():
                out.append(_f("hsts_no_subdomains", "HSTS does not cover subdomains", S.INFO,
                    "ترويسة HSTS لا تتضمن includeSubDomains.", loc,
                    "النطاقات الفرعية غير محمية بنفس السياسة.",
                    "أضف includeSubDomains بعد التأكد أن كل النطاقات الفرعية تدعم HTTPS.",
                    MDN + "Strict-Transport-Security"))

    csp = resp.header("content-security-policy")
    d = {}
    if not csp:
        out.append(_f("csp_missing", "Missing Content-Security-Policy", S.MEDIUM,
            "لا توجد سياسة Content-Security-Policy.", loc,
            "تزداد خطورة هجمات XSS وحقن المحتوى لعدم وجود طبقة دفاع إضافية.",
            "عرّف سياسة تبدأ بـ default-src 'self' ثم افتح فقط ما يلزم.",
            MDN + "Content-Security-Policy"))
    else:
        d = _csp_directives(csp)
        script = d.get("script-src", d.get("default-src", []))
        if "'unsafe-inline'" in script and not any(s.startswith(("'nonce-", "'sha")) for s in script):
            out.append(_f("csp_unsafe_inline", "CSP allows unsafe-inline scripts", S.MEDIUM,
                "السياسة تسمح بـ 'unsafe-inline' للسكربتات.", loc,
                "يُبطل ذلك معظم حماية CSP ضد XSS.",
                "استخدم nonce أو hash بدلاً من 'unsafe-inline'.", MDN + "Content-Security-Policy/script-src"))
        if "'unsafe-eval'" in script:
            out.append(_f("csp_unsafe_eval", "CSP allows unsafe-eval", S.LOW,
                "السياسة تسمح بـ 'unsafe-eval'.", loc,
                "يسمح بتنفيذ نصوص ديناميكية عبر eval().",
                "أزل 'unsafe-eval' وعدّل الكود الذي يعتمد عليه.", MDN + "Content-Security-Policy/script-src"))
        if any(s in ("*", "http:", "data:") for s in script):
            out.append(_f("csp_wildcard", "CSP script-src is overly permissive", S.MEDIUM,
                "script-src يحتوي على * أو http: أو data:.", loc,
                "يمكن تحميل سكربتات من مصادر غير موثوقة.",
                "حدّد المصادر بالاسم بدقة.", MDN + "Content-Security-Policy/script-src"))

    has_fa = "frame-ancestors" in d
    if not resp.header("x-frame-options") and not has_fa:
        out.append(_f("clickjacking", "Missing clickjacking protection", S.MEDIUM,
            "لا توجد ترويسة X-Frame-Options ولا توجيه frame-ancestors.", loc,
            "يمكن تضمين الصفحة داخل iframe في موقع خبيث (Clickjacking).",
            "أضف X-Frame-Options: DENY أو CSP: frame-ancestors 'none'.", MDN + "X-Frame-Options"))

    if (resp.header("x-content-type-options") or "").lower() != "nosniff":
        out.append(_f("nosniff_missing", "Missing X-Content-Type-Options", S.LOW,
            "الترويسة X-Content-Type-Options: nosniff غير موجودة.", loc,
            "قد يخمّن المتصفح نوع المحتوى ويشغّل ملفات بشكل غير مقصود.",
            "أضف X-Content-Type-Options: nosniff.", MDN + "X-Content-Type-Options"))

    if not resp.header("referrer-policy"):
        out.append(_f("referrer_policy_missing", "Missing Referrer-Policy", S.LOW,
            "لا توجد سياسة Referrer-Policy.", loc,
            "قد تتسرب عناوين الصفحات (وما فيها من معرّفات) إلى مواقع خارجية.",
            "أضف Referrer-Policy: strict-origin-when-cross-origin.", MDN + "Referrer-Policy"))

    if not resp.header("permissions-policy"):
        out.append(_f("permissions_policy_missing", "Missing Permissions-Policy", S.INFO,
            "لا توجد ترويسة Permissions-Policy.", loc,
            "ميزات المتصفح (الكاميرا، الموقع...) غير مقيّدة صراحةً.",
            "قيّد الميزات غير المستخدمة، مثال: Permissions-Policy: camera=(), geolocation=()",
            MDN + "Permissions-Policy"))

    if (resp.header("access-control-allow-origin") or "") == "*":
        out.append(_f("cors_wildcard", "CORS allows any origin", S.LOW,
            "Access-Control-Allow-Origin: * على هذه الصفحة.", loc,
            "أي موقع يمكنه قراءة استجابات هذا المورد من المتصفح.",
            "قيّد الأصول المسموحة إن كان المحتوى غير عام.", MDN + "Access-Control-Allow-Origin"))
    if not out:
        return out
    return out
