"""فحص إعدادات DNS العامة: SPF وDMARC وCAA وMX."""
from typing import Protocol
from ..findings import Finding, Severity as S

CAT = "DNS & Email Security"


class DnsError(Exception):
    pass


class DnsResolver(Protocol):
    def query(self, name: str, rtype: str) -> list: ...


class DnsPythonResolver:
    """محلّل DNS مبني على dnspython (يُستورد عند الحاجة)."""
    def __init__(self, lifetime: float = 5.0):
        try:
            import dns.resolver  # noqa
        except ImportError as e:
            raise DnsError("مكتبة dnspython غير مثبتة") from e
        import dns.resolver
        self._dns = dns
        self._r = dns.resolver.Resolver()
        self._r.lifetime = lifetime

    def query(self, name, rtype):
        d = self._dns.resolver
        try:
            ans = self._r.resolve(name, rtype)
        except (d.NXDOMAIN, d.NoAnswer, d.NoNameservers):
            return []
        except Exception as e:
            raise DnsError(str(e)) from e
        if rtype == "TXT":
            return ["".join(s.decode("utf-8", "replace") for s in r.strings) for r in ans]
        return [r.to_text() for r in ans]


def _f(cid, title, sev, desc, loc, impact, rec, ref):
    return Finding(f"dns.{cid}", title, sev, CAT, desc, loc, impact, rec, ref)


def check_dns(host: str, dns: DnsResolver) -> list:
    out = []
    mx = dns.query(host, "MX")
    sends_mail = any(m.split()[-1].strip(".") not in ("", ".") for m in mx) if mx else False
    # null MX (RFC 7505) يعني أن النطاق لا يستقبل بريداً
    sends_mail = sends_mail and not (len(mx) == 1 and mx[0].split()[-1] == ".")

    spf = [t for t in dns.query(host, "TXT") if t.lower().startswith("v=spf1")]
    if len(spf) > 1:
        out.append(_f("spf_multiple", "Multiple SPF records", S.MEDIUM,
            "يوجد أكثر من سجل SPF، وهذا يجعل التحقق يفشل.", host,
            "قد يُرفض بريدك المشروع أو يُتجاهل SPF.", "ادمج السجلات في سجل واحد.",
            "https://datatracker.ietf.org/doc/html/rfc7208#section-3.2"))
    elif not spf:
        out.append(_f("spf_missing", "Missing SPF record", S.MEDIUM if sends_mail else S.LOW,
            "لا يوجد سجل SPF للنطاق.", host,
            "يسهل انتحال بريد النطاق (Spoofing).",
            "أضف سجل TXT مثل: v=spf1 include:<مزودك> -all",
            "https://datatracker.ietf.org/doc/html/rfc7208"))
    else:
        rec = spf[0].lower().split()
        if "+all" in rec or "all" in rec:
            out.append(_f("spf_allow_all", "SPF allows any sender", S.HIGH,
                "السجل ينتهي بـ +all أي يسمح لأي خادم بإرسال البريد.", host,
                "SPF عديم الفائدة ويمكن انتحال النطاق بسهولة.", "استبدله بـ -all أو ~all.",
                "https://datatracker.ietf.org/doc/html/rfc7208#section-5.1"))
        elif "?all" in rec:
            out.append(_f("spf_neutral", "SPF policy is neutral", S.MEDIUM,
                "السجل ينتهي بـ ?all ولا يفرض أي سياسة.", host,
                "لا يُرفض البريد المنتحل.", "استخدم -all أو ~all.",
                "https://datatracker.ietf.org/doc/html/rfc7208#section-5.1"))

    dmarc = [t for t in dns.query(f"_dmarc.{host}", "TXT") if t.lower().startswith("v=dmarc1")]
    if not dmarc:
        out.append(_f("dmarc_missing", "Missing DMARC record", S.MEDIUM if sends_mail else S.LOW,
            "لا يوجد سجل DMARC.", f"_dmarc.{host}",
            "لا توجد سياسة لمعالجة البريد المنتحل ولا تقارير عنه.",
            "أضف: v=DMARC1; p=quarantine; rua=mailto:dmarc@<نطاقك>",
            "https://datatracker.ietf.org/doc/html/rfc7489"))
    else:
        tags = {k.strip(): v.strip().lower() for k, _, v in
                (p.partition("=") for p in dmarc[0].split(";") if "=" in p)}
        if tags.get("p") == "none":
            out.append(_f("dmarc_none", "DMARC policy is p=none", S.LOW,
                "السياسة p=none للمراقبة فقط.", f"_dmarc.{host}",
                "البريد المنتحل لا يُحجب.", "انتقل تدريجياً إلى quarantine ثم reject.",
                "https://datatracker.ietf.org/doc/html/rfc7489#section-6.3"))

    if not dns.query(host, "CAA"):
        out.append(_f("caa_missing", "No CAA record", S.INFO,
            "لا يوجد سجل CAA يحدد الجهات المخوّلة بإصدار شهادات للنطاق.", host,
            "يمكن لأي جهة إصدار شهادات للنطاق نظرياً.",
            'أضف مثلاً: 0 issue "letsencrypt.org"',
            "https://datatracker.ietf.org/doc/html/rfc8659"))
    return out
