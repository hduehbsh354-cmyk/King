"""إثبات ملكية النطاق: سجل DNS TXT أو ملف على الموقع. لا فحص قبل التحقق."""
import secrets
from typing import Optional
from .checks.dns_checks import DnsError, DnsResolver
from .http_client import fetch
from .ssrf import Resolver

DNS_PREFIX = "_cybershield"
FILE_PATH = "/.well-known/cybershield-verify.txt"
TOKEN_PREFIX = "cybershield-verify="


def generate_token() -> str:
    return TOKEN_PREFIX + secrets.token_hex(16)


def instructions(host: str, token: str) -> dict:
    return {
        "dns": {"type": "TXT", "name": f"{DNS_PREFIX}.{host}", "value": token},
        "file": {"url": f"https://{host}{FILE_PATH}", "content": token},
    }


def verify_dns(host: str, token: str, dns: DnsResolver) -> bool:
    try:
        records = dns.query(f"{DNS_PREFIX}.{host}", "TXT")
    except DnsError:
        return False
    return any(r.strip().strip('"') == token for r in records)


def verify_file(host: str, token: str, resolver: Optional[Resolver] = None) -> bool:
    for scheme in ("https", "http"):
        try:
            r = fetch(f"{scheme}://{host}{FILE_PATH}", scope_domain=host, resolver=resolver,
                      follow=True, max_bytes=4096)
        except Exception:
            continue
        if r.status == 200 and r.text.strip() == token:
            return True
    return False


def verify(host: str, token: str, dns: Optional[DnsResolver],
           resolver: Optional[Resolver] = None) -> Optional[str]:
    """يعيد طريقة النجاح ('dns' أو 'file') أو None."""
    if dns and verify_dns(host, token, dns):
        return "dns"
    if verify_file(host, token, resolver):
        return "file"
    return None
