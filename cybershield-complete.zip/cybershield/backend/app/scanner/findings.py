"""نموذج النتائج وحساب درجة الأمان."""
from __future__ import annotations
from dataclasses import dataclass
from enum import IntEnum


class Severity(IntEnum):
    INFO = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

    @property
    def label(self) -> str:
        return self.name.lower()


@dataclass
class Finding:
    check_id: str          # معرّف ثابت يُستخدم في مقارنة الفحوصات
    title: str             # العنوان بالإنجليزية
    severity: Severity
    category: str
    description: str
    location: str
    impact: str
    recommendation: str
    reference: str = ""

    def to_dict(self) -> dict:
        return {
            "check_id": self.check_id, "title": self.title,
            "severity": self.severity.label, "category": self.category,
            "description": self.description, "location": self.location,
            "impact": self.impact, "recommendation": self.recommendation,
            "reference": self.reference,
        }


PENALTY = {Severity.CRITICAL: 25, Severity.HIGH: 15, Severity.MEDIUM: 7,
           Severity.LOW: 3, Severity.INFO: 0}


def dedupe(findings: list[Finding]) -> list[Finding]:
    seen, out = set(), []
    for f in findings:
        key = (f.check_id, f.location)
        if key not in seen:
            seen.add(key)
            out.append(f)
    return sorted(out, key=lambda f: -f.severity)


def summarize(findings: list[Finding]) -> dict:
    counts = {s.label: 0 for s in sorted(Severity, reverse=True)}
    for f in findings:
        counts[f.severity.label] += 1
    score = max(0, 100 - sum(PENALTY[f.severity] for f in findings))
    grade = "A" if score >= 90 else "B" if score >= 80 else "C" if score >= 65 \
        else "D" if score >= 50 else "F"
    return {"counts": counts, "score": score, "grade": grade}
