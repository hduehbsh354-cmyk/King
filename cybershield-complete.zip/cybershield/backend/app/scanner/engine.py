"""محرك الفحص: ينسّق الفحوصات السلبية على نطاق موثّق الملكية."""
from __future__ import annotations
import time
from datetime import datetime, timezone
from typing import Callable, Optional

from .checks.cookies import analyze_cookies
from .checks.dns_checks import DnsError, DnsPythonResolver, DnsResolver, check_dns
from .checks.fingerprint import analyze_fingerprint
from .checks.headers import analyze_headers
from .checks.https_redirect import check_http_redirect
from .checks.security_txt import check_security_txt
from .checks.tls import check_tls
from .findings import Finding, Severity, dedupe, summarize
from .http_client import fetch
from .ssrf import Resolver, resolve_public, normalize_domain


def run_scan(hostname: str, *, dns: Optional[DnsResolver] = None,
             resolver: Optional[Resolver] = None,
             progress: Optional[Callable[[str, int], None]] = None) -> dict:
    """ينفّذ الفحص ويعيد قاموساً جاهزاً للتخزين. يرفع TargetNotAllowed للأهداف المرفوضة."""
    host = normalize_domain(hostname)
    started = datetime.now(timezone.utc)
    t0 = time.monotonic()
    ips = resolve_public(host, 443, resolver)          # SSRF guard
    findings: list = []
    errors: dict = {}
    meta: dict = {"ips": ips}

    if dns is None:
        try:
            dns = DnsPythonResolver()
        except DnsError as e:
            errors["dns"] = str(e)

    steps: list = []
    page = {"resp": None}

    def get_page():
        for scheme in ("https", "http"):
            try:
                page["resp"] = fetch(f"{scheme}://{host}/", scope_domain=host, resolver=resolver)
                return []
            except Exception as e:
                errors["fetch_" + scheme] = f"{type(e).__name__}: {e}"
        return [Finding("site.unreachable", "Site could not be fetched", Severity.INFO,
                        "General", "تعذّر جلب الصفحة الرئيسية عبر HTTPS أو HTTP.", host,
                        "لم تتم الفحوصات المعتمدة على محتوى الصفحة.",
                        "تأكد أن الموقع متاح للعامة ولا يحجب عنوان الفاحص.")]

    def tls():
        f, info = check_tls(host, ips[0])
        meta["tls"] = info
        return f

    def page_check(fn):
        return lambda: fn(page["resp"]) if page["resp"] else []

    def tls_verify_note():
        r = page["resp"]
        if r and r.tls_verified is False and not any(
                f.check_id.startswith("tls.") for f in findings):
            return [Finding("tls.untrusted", "Certificate not trusted", Severity.MEDIUM, "SSL/TLS",
                            f"فشل التحقق من الشهادة: {r.tls_error}.", host,
                            "قد تظهر تحذيرات أمان للزوار.", "أصلح سلسلة الشهادات.", "")]
        return []

    steps = [
        ("جلب الصفحة الرئيسية", get_page),
        ("فحص شهادة SSL/TLS", tls),
        ("التحويل من HTTP إلى HTTPS", lambda: check_http_redirect(host, resolver)),
        ("رؤوس HTTP الأمنية", page_check(analyze_headers)),
        ("إعدادات Cookies", page_check(analyze_cookies)),
        ("إصدارات البرمجيات المكشوفة", page_check(analyze_fingerprint)),
        ("ملف security.txt", lambda: check_security_txt(host, resolver)),
        ("إعدادات DNS والبريد", (lambda: check_dns(host, dns)) if dns else (lambda: [])),
        ("مراجعة نهائية", tls_verify_note),
    ]
    for i, (label, fn) in enumerate(steps):
        if progress:
            progress(label, int(i / len(steps) * 100))
        try:
            findings += fn()
        except Exception as e:  # فشل فحص واحد لا يوقف البقية
            errors[label] = f"{type(e).__name__}: {e}"

    findings = dedupe(findings)
    if progress:
        progress("اكتمل", 100)
    resp = page["resp"]
    return {
        "hostname": host,
        "started_at": started,
        "finished_at": datetime.now(timezone.utc),
        "duration_s": round(time.monotonic() - t0, 2),
        "final_url": resp.url if resp else None,
        "http_status": resp.status if resp else None,
        "meta": meta,
        "errors": errors,
        "findings": [f.to_dict() for f in findings],
        **summarize(findings),
    }
