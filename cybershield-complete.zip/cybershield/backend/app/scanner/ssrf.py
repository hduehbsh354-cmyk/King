"""حماية SSRF: التحقق من النطاق والمنفذ وأن العناوين المحلولة عامة فقط."""
from __future__ import annotations
import ipaddress
import re
import socket
from typing import Callable, Optional
from urllib.parse import urlsplit

ALLOWED_PORTS = {80, 443, 8080, 8443}
_LABEL = re.compile(r"^(?!-)[a-z0-9-]{1,63}(?<!-)$")

Resolver = Callable[[str, int], list]


class TargetNotAllowed(ValueError):
    """الهدف مرفوض لأسباب أمنية أو لأنه غير صالح."""


def normalize_domain(value: str) -> str:
    """يقبل نطاقاً أو رابطاً ويعيد اسم المضيف المُطبَّع، ويرفض عناوين IP."""
    v = (value or "").strip().lower()
    if not v:
        raise TargetNotAllowed("أدخل رابط الموقع أو النطاق.")
    if "://" not in v:
        v = "http://" + v
    try:
        parts = urlsplit(v)
        host = (parts.hostname or "").rstrip(".")
        _ = parts.port
    except ValueError:
        raise TargetNotAllowed("الرابط غير صالح.")
    if parts.username or parts.password:
        raise TargetNotAllowed("الروابط التي تحتوي على بيانات دخول غير مسموحة.")
    if not host:
        raise TargetNotAllowed("الرابط غير صالح.")
    try:
        ipaddress.ip_address(host)
        is_ip = True
    except ValueError:
        is_ip = False
    if is_ip:
        raise TargetNotAllowed("عناوين IP غير مسموحة، استخدم اسم نطاق.")
    try:
        host = host.encode("idna").decode("ascii")
    except UnicodeError:
        raise TargetNotAllowed("اسم النطاق غير صالح.")
    labels = host.split(".")
    if len(host) > 253 or len(labels) < 2 or not all(_LABEL.match(l) for l in labels):
        raise TargetNotAllowed("اسم النطاق غير صالح.")
    if labels[-1] in {"local", "localhost", "internal", "lan", "intranet", "corp", "home"}:
        raise TargetNotAllowed("النطاقات الداخلية غير مسموحة.")
    return host


def is_public_ip(ip: str) -> bool:
    addr = ipaddress.ip_address(ip)
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped:
        addr = addr.ipv4_mapped
    return addr.is_global and not addr.is_multicast


def _system_resolver(host: str, port: int) -> list:
    infos = socket.getaddrinfo(host, port, proto=socket.IPPROTO_TCP)
    return list(dict.fromkeys(i[4][0] for i in infos))


def resolve_public(host: str, port: int = 443,
                   resolver: Optional[Resolver] = None) -> list:
    """يحلّ الاسم ويرفض إن كان أي عنوان غير عام."""
    try:
        ips = (resolver or _system_resolver)(host, port)
    except OSError:
        raise TargetNotAllowed("تعذّر حلّ اسم النطاق.")
    if not ips:
        raise TargetNotAllowed("لا يوجد عنوان IP لهذا النطاق.")
    for ip in ips:
        if not is_public_ip(ip):
            raise TargetNotAllowed("النطاق يشير إلى عنوان داخلي/خاص، وهذا غير مسموح.")
    return ips


def in_scope(host: str, scope_domain: str) -> bool:
    host, scope = host.lower().rstrip("."), scope_domain.lower()
    return host == scope or host.endswith("." + scope)


def validate_url(url: str, scope_domain: str) -> tuple:
    """يتحقق من الرابط ضمن النطاق المصرّح، ويعيد (scheme, host, port)."""
    p = urlsplit(url)
    if p.scheme not in ("http", "https"):
        raise TargetNotAllowed("البروتوكول غير مسموح.")
    if p.username or p.password:
        raise TargetNotAllowed("بيانات دخول داخل الرابط غير مسموحة.")
    host = (p.hostname or "").lower()
    if not host or not in_scope(host, scope_domain):
        raise TargetNotAllowed("الرابط خارج النطاق المصرّح به.")
    port = p.port or (443 if p.scheme == "https" else 80)
    if port not in ALLOWED_PORTS:
        raise TargetNotAllowed("المنفذ غير مسموح.")
    return p.scheme, host, port
