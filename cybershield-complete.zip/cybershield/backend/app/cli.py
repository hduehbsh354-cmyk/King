"""python -m app.cli create-admin EMAIL PASSWORD"""
import sys
from sqlalchemy import select
from .database import Base, SessionLocal, engine
from .models import User
from .security import hash_password, password_problems


def main():
    if len(sys.argv) != 4 or sys.argv[1] != "create-admin":
        sys.exit("usage: python -m app.cli create-admin EMAIL PASSWORD")
    email, pw = sys.argv[2].lower(), sys.argv[3]
    if p := password_problems(pw):
        sys.exit("; ".join(p))
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        u = db.scalar(select(User).where(User.email == email))
        if u:
            u.role, u.password_hash = "admin", hash_password(pw)
        else:
            db.add(User(email=email, full_name="Admin", role="admin", password_hash=hash_password(pw)))
        db.commit()
    print("admin ready:", email)


if __name__ == "__main__":
    main()
