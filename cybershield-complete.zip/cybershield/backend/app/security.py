"""تجزئة كلمات المرور (scrypt)، JWT، ورموز عشوائية آمنة."""
import base64
import hashlib
import hmac
import secrets
import time
from typing import Optional

import jwt

_N, _R, _P = 2 ** 15, 8, 1


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=_N, r=_R, p=_P, maxmem=128 * 1024 * 1024, dklen=32)
    b = lambda x: base64.b64encode(x).decode()
    return f"scrypt${_N}${_R}${_P}${b(salt)}${b(dk)}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, n, r, p, salt, dk = stored.split("$")
        calc = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt), n=int(n), r=int(r),
                              p=int(p), maxmem=128 * 1024 * 1024, dklen=32)
        return hmac.compare_digest(calc, base64.b64decode(dk))
    except Exception:
        return False


def password_problems(pw: str) -> list:
    out = []
    if len(pw) < 10: out.append("كلمة المرور يجب ألا تقل عن 10 أحرف")
    if pw.lower() == pw or pw.upper() == pw: out.append("استخدم أحرفاً كبيرة وصغيرة")
    if not any(c.isdigit() for c in pw): out.append("أضف رقماً واحداً على الأقل")
    if len(pw) > 128: out.append("كلمة المرور طويلة جداً")
    return out


def new_token() -> str:
    return secrets.token_urlsafe(32)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def create_access_token(secret: str, user_id: int, role: str, ttl_min: int, sid: Optional[int] = None) -> str:
    now = int(time.time())
    return jwt.encode({"sub": str(user_id), "role": role, "sid": sid, "iat": now,
                       "exp": now + ttl_min * 60, "typ": "access"}, secret, algorithm="HS256")


def decode_access_token(secret: str, token: str) -> Optional[dict]:
    try:
        data = jwt.decode(token, secret, algorithms=["HS256"], options={"require": ["exp", "sub"]})
    except jwt.PyJWTError:
        return None
    return data if data.get("typ") == "access" else None
