"""تحديد المعدّل: Redis عند توفره وإلا ذاكرة العملية (للتطوير/عملية واحدة)."""
import threading
import time
from collections import defaultdict, deque


class MemoryLimiter:
    def __init__(self):
        self._hits = defaultdict(deque)
        self._lock = threading.Lock()

    def hit(self, key: str, limit: int, window_s: int) -> tuple:
        """يعيد (مسموح، ثواني حتى إعادة المحاولة)."""
        now = time.monotonic()
        with self._lock:
            q = self._hits[key]
            while q and q[0] <= now - window_s:
                q.popleft()
            if len(q) >= limit:
                return False, max(1, int(q[0] + window_s - now))
            q.append(now)
            return True, 0


class RedisLimiter:
    def __init__(self, client):
        self.r = client

    def hit(self, key: str, limit: int, window_s: int) -> tuple:
        k = f"rl:{key}"
        n = self.r.incr(k)
        if n == 1:
            self.r.expire(k, window_s)
        if n > limit:
            return False, max(1, self.r.ttl(k))
        return True, 0


def make_limiter(redis_url: str = ""):
    if redis_url:
        try:
            import redis
            c = redis.Redis.from_url(redis_url, socket_timeout=1)
            c.ping()
            return RedisLimiter(c)
        except Exception:
            pass
    return MemoryLimiter()
