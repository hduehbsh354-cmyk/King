import os
from dataclasses import dataclass
from functools import lru_cache


@dataclass(frozen=True)
class Settings:
    env: str
    secret_key: str
    database_url: str
    redis_url: str
    cors_origins: list
    cookie_secure: bool
    frontend_url: str
    smtp_host: str
    smtp_port: int
    smtp_user: str
    smtp_password: str
    smtp_from: str
    access_ttl_min: int = 15
    refresh_ttl_days: int = 14
    max_running_scans_per_user: int = 2
    max_scans_per_day: int = 20
    max_domains_per_user: int = 25


@lru_cache
def get_settings() -> Settings:
    env = os.getenv("ENV", "development")
    secret = os.getenv("SECRET_KEY", "dev-only-insecure-key-change-me-0123456789")
    if env == "production" and (len(secret) < 32 or secret.startswith("dev-only")):
        raise RuntimeError("SECRET_KEY قوي مطلوب في وضع production")
    return Settings(
        env=env, secret_key=secret,
        database_url=os.getenv("DATABASE_URL", "sqlite:///./dev.db"),
        redis_url=os.getenv("REDIS_URL", ""),
        cors_origins=[o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000,http://localhost:3000").split(",") if o.strip()],
        cookie_secure=os.getenv("COOKIE_SECURE", "true" if env == "production" else "false").lower() == "true",
        frontend_url=os.getenv("FRONTEND_URL", "http://localhost:3000"),
        smtp_host=os.getenv("SMTP_HOST", ""), smtp_port=int(os.getenv("SMTP_PORT", "587")),
        smtp_user=os.getenv("SMTP_USER", ""), smtp_password=os.getenv("SMTP_PASSWORD", ""),
        smtp_from=os.getenv("SMTP_FROM", "no-reply@cybershield.local"),
    )
