from datetime import datetime, timezone
from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session
from .config import get_settings
from .database import get_db
from .models import User, UserSession
from .ratelimit import make_limiter
from .security import decode_access_token
from .services.audit import client_ip

limiter = make_limiter(get_settings().redis_url)


def rate_limit(name: str, limit: int, window_s: int):
    def dep(request: Request):
        ok, retry = limiter.hit(f"{name}:{client_ip(request)}", limit, window_s)
        if not ok:
            raise HTTPException(429, "طلبات كثيرة، حاول لاحقاً.", headers={"Retry-After": str(retry)})
    return dep


def get_current_user(request: Request, db: Session = Depends(get_db)) -> User:
    auth = request.headers.get("authorization", "")
    if not auth.lower().startswith("bearer "):
        raise HTTPException(401, "غير مصرّح", headers={"WWW-Authenticate": "Bearer"})
    data = decode_access_token(get_settings().secret_key, auth[7:])
    if not data:
        raise HTTPException(401, "انتهت الجلسة، سجّل الدخول مجدداً", headers={"WWW-Authenticate": "Bearer"})
    user = db.get(User, int(data["sub"]))
    sess = db.get(UserSession, data.get("sid")) if data.get("sid") else None
    now = datetime.now(timezone.utc)
    if (not user or not user.is_active or not sess or sess.user_id != user.id or sess.revoked_at
            or sess.expires_at.replace(tzinfo=sess.expires_at.tzinfo or timezone.utc) < now):
        raise HTTPException(401, "الجلسة غير صالحة")
    if user.is_blocked:
        raise HTTPException(403, "هذا الحساب محظور")
    request.state.session_id = sess.id
    return user


def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(403, "صلاحيات غير كافية")
    return user
