import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pathlib import Path
from sqlalchemy import update

from .config import get_settings
from .database import Base, SessionLocal, engine
from .models import Scan, utcnow
from .routers import auth, domains, scans

cfg = get_settings()
logging.basicConfig(level=logging.INFO)


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)  # للإنتاج الكبير يُفضّل Alembic
    with SessionLocal() as db:  # فحوصات علقت بسبب إعادة تشغيل الخدمة
        db.execute(update(Scan).where(Scan.status.in_(("queued", "running")))
                   .values(status="failed", error="أُوقفت الخدمة أثناء الفحص", finished_at=utcnow()))
        db.commit()
    yield


app = FastAPI(title="Cyber Shield Pro API", version="0.1.0", lifespan=lifespan,
              docs_url=None if cfg.env == "production" else "/api/docs",
              redoc_url=None, openapi_url=None if cfg.env == "production" else "/api/openapi.json")

app.add_middleware(CORSMiddleware, allow_origins=cfg.cors_origins, allow_credentials=True,
                   allow_methods=["GET", "POST", "PATCH", "DELETE"],
                   allow_headers=["Authorization", "Content-Type", "X-CSRF-Token"])


@app.middleware("http")
async def security_middleware(request: Request, call_next):
    # فحص Origin للطلبات المغيِّرة: طبقة CSRF إضافية فوق SameSite=Strict
    origin = request.headers.get("origin")
    if request.method in ("POST", "PUT", "PATCH", "DELETE") and origin and origin not in cfg.cors_origins:
        return JSONResponse({"detail": "مصدر الطلب غير مسموح"}, status_code=403)
    resp = await call_next(request)
    resp.headers.update({"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY",
                         "Referrer-Policy": "no-referrer", "Cache-Control": "no-store"})
    return resp


app.include_router(auth.router)
app.include_router(domains.router)
app.include_router(scans.router)


@app.get("/api/health")
def health():
    return {"status": "ok"}


_FRONT = Path(__file__).resolve().parent.parent.parent / "frontend" / "index.html"


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(_FRONT) if _FRONT.exists() else JSONResponse({"detail": "frontend missing"}, 404)
