"""تشغيل الفحص في الخلفية وحفظ النتائج. يمكن استبداله بعامل Redis/RQ لاحقاً."""
import logging
from ..database import SessionLocal
from ..models import Domain, FindingRow, Scan, utcnow
from ..scanner.engine import run_scan
from ..scanner.findings import Severity
from ..scanner.ssrf import TargetNotAllowed

log = logging.getLogger("scan_runner")


def run_scan_job(scan_id: int) -> None:
    db = SessionLocal()
    try:
        scan = db.get(Scan, scan_id)
        if not scan or scan.status != "queued":
            return
        domain = db.get(Domain, scan.domain_id)
        if not domain or not domain.verified_at:
            scan.status, scan.error, scan.finished_at = "failed", "النطاق غير موثّق الملكية", utcnow()
            db.commit()
            return
        scan.status, scan.started_at = "running", utcnow()
        db.commit()

        def progress(step: str, pct: int):
            scan.step, scan.progress = step, pct
            db.commit()

        try:
            r = run_scan(domain.hostname, progress=progress)
        except TargetNotAllowed as e:
            scan.status, scan.error = "failed", str(e)
        except Exception:
            log.exception("scan %s failed", scan_id)
            scan.status, scan.error = "failed", "حدث خطأ غير متوقع أثناء الفحص"
        else:
            for f in r["findings"]:
                db.add(FindingRow(scan_id=scan.id, severity_rank=int(Severity[f["severity"].upper()]),
                                  **{k: f[k] for k in ("check_id", "title", "severity", "category",
                                                       "description", "location", "impact",
                                                       "recommendation", "reference")}))
            scan.status, scan.progress, scan.step = "completed", 100, "اكتمل"
            scan.score, scan.grade, scan.counts = r["score"], r["grade"], r["counts"]
            scan.details = {k: r[k] for k in ("final_url", "http_status", "duration_s", "meta", "errors")}
        scan.finished_at = utcnow()
        db.commit()
    finally:
        db.close()
