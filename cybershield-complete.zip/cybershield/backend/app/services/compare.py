"""مقارنة نتيجتي فحص (الأحدث مقابل الأقدم)."""


def _key(f): return (f["check_id"], f["location"])


def compare_scans(old: dict, new: dict) -> dict:
    o = {_key(f): f for f in old["findings"]}
    n = {_key(f): f for f in new["findings"]}
    return {
        "new": [n[k] for k in n if k not in o],
        "resolved": [o[k] for k in o if k not in n],
        "unchanged": [n[k] for k in n if k in o],
        "score_delta": new["score"] - old["score"],
    }
