import logging
import smtplib
from email.message import EmailMessage
from ..config import get_settings

log = logging.getLogger("mailer")


def send_email(to: str, subject: str, body: str) -> None:
    s = get_settings()
    if not s.smtp_host:
        log.warning("SMTP غير مهيأ. [%s] إلى %s:\n%s", subject, to, body)
        return
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = s.smtp_from, to, subject
    msg.set_content(body)
    try:
        with smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=10) as c:
            c.starttls()
            if s.smtp_user:
                c.login(s.smtp_user, s.smtp_password)
            c.send_message(msg)
    except Exception:
        log.exception("فشل إرسال البريد")
