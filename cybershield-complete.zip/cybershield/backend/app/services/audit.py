from fastapi import Request
from sqlalchemy.orm import Session
from ..models import AuditLog


def client_ip(request: Request) -> str:
    return request.client.host if request.client else ""


def audit(db: Session, action: str, request: Request = None, user_id: int = None, **detail):
    db.add(AuditLog(user_id=user_id, action=action, ip=client_ip(request) if request else "",
                    detail=detail or None))
