import hmac
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from ..config import get_settings
from ..database import get_db
from ..deps import get_current_user, limiter, rate_limit
from ..models import PasswordReset, User, UserSession, utcnow
from ..schemas import (ChangePasswordIn, ForgotIn, LoginIn, ProfileIn, RegisterIn, ResetIn,
                       SessionOut, TokenOut, UserOut)
from ..security import (create_access_token, hash_password, hash_token, new_token,
                        password_problems, verify_password)
from ..services.audit import audit, client_ip
from ..services.mailer import send_email

router = APIRouter(prefix="/api/auth", tags=["auth"])
REFRESH, CSRF = "refresh_token", "csrf_token"
_DUMMY = hash_password("dummy-password-for-timing-equalization")
MAX_FAILS, LOCK_MIN = 5, 15


def _aware(dt: datetime) -> datetime:
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _set_cookies(resp: Response, refresh: str):
    s = get_settings()
    age = s.refresh_ttl_days * 86400
    common = dict(max_age=age, secure=s.cookie_secure, samesite="strict")
    resp.set_cookie(REFRESH, refresh, httponly=True, path="/api/auth", **common)
    resp.set_cookie(CSRF, new_token(), httponly=False, path="/", **common)


def _issue(db: Session, user: User, request: Request, response: Response) -> TokenOut:
    s = get_settings()
    refresh = new_token()
    sess = UserSession(user_id=user.id, refresh_hash=hash_token(refresh),
                       user_agent=(request.headers.get("user-agent") or "")[:255],
                       ip=client_ip(request),
                       expires_at=utcnow() + timedelta(days=s.refresh_ttl_days))
    db.add(sess)
    db.flush()
    _set_cookies(response, refresh)
    token = create_access_token(s.secret_key, user.id, user.role, s.access_ttl_min, sess.id)
    return TokenOut(access_token=token, user=UserOut.model_validate(user))


def _revoke_all(db: Session, user_id: int, except_id: int = None):
    q = update(UserSession).where(UserSession.user_id == user_id, UserSession.revoked_at.is_(None))
    if except_id:
        q = q.where(UserSession.id != except_id)
    db.execute(q.values(revoked_at=utcnow()))


@router.post("/register", response_model=TokenOut, status_code=201,
             dependencies=[Depends(rate_limit("register", 5, 3600))])
def register(body: RegisterIn, request: Request, response: Response, db: Session = Depends(get_db)):
    problems = password_problems(body.password)
    if problems:
        raise HTTPException(422, "؛ ".join(problems))
    email = body.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "هذا البريد مسجّل مسبقاً")
    user = User(email=email, full_name=body.full_name.strip(), password_hash=hash_password(body.password))
    db.add(user)
    db.flush()
    audit(db, "auth.register", request, user.id)
    out = _issue(db, user, request, response)
    db.commit()
    return out


@router.post("/login", response_model=TokenOut, dependencies=[Depends(rate_limit("login", 20, 300))])
def login(body: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    email = body.email.lower()
    ok, retry = limiter.hit(f"login-email:{email}", 10, 900)
    if not ok:
        raise HTTPException(429, "محاولات كثيرة، حاول لاحقاً.", headers={"Retry-After": str(retry)})
    user = db.scalar(select(User).where(User.email == email))
    now = utcnow()
    if user and user.locked_until and _aware(user.locked_until) > now:
        raise HTTPException(423, "الحساب مقفل مؤقتاً بسبب محاولات فاشلة. حاول بعد قليل.")
    valid = verify_password(body.password, user.password_hash if user else _DUMMY)
    if not user or not valid:
        if user:
            user.failed_logins += 1
            if user.failed_logins >= MAX_FAILS:
                user.locked_until, user.failed_logins = now + timedelta(minutes=LOCK_MIN), 0
                audit(db, "auth.locked", request, user.id)
            audit(db, "auth.login_failed", request, user.id)
            db.commit()
        raise HTTPException(401, "البريد أو كلمة المرور غير صحيحة")
    if not user.is_active or user.is_blocked:
        audit(db, "auth.login_blocked", request, user.id)
        db.commit()
        raise HTTPException(403, "هذا الحساب غير مفعّل أو محظور")
    user.failed_logins, user.locked_until, user.last_login_at = 0, None, now
    out = _issue(db, user, request, response)
    audit(db, "auth.login", request, user.id)
    db.commit()
    return out


def _csrf_ok(request: Request) -> bool:
    c, h = request.cookies.get(CSRF), request.headers.get("x-csrf-token")
    return bool(c and h and hmac.compare_digest(c, h))


@router.post("/refresh", response_model=TokenOut)
def refresh(request: Request, response: Response, db: Session = Depends(get_db)):
    if not _csrf_ok(request):
        raise HTTPException(403, "فشل التحقق من CSRF")
    raw = request.cookies.get(REFRESH)
    sess = db.scalar(select(UserSession).where(UserSession.refresh_hash == hash_token(raw))) if raw else None
    if not sess or sess.revoked_at or _aware(sess.expires_at) < utcnow():
        raise HTTPException(401, "الجلسة غير صالحة")
    user = db.get(User, sess.user_id)
    if not user or not user.is_active or user.is_blocked:
        raise HTTPException(401, "الجلسة غير صالحة")
    new = new_token()  # تدوير رمز التحديث
    sess.refresh_hash, sess.last_used_at = hash_token(new), utcnow()
    _set_cookies(response, new)
    s = get_settings()
    token = create_access_token(s.secret_key, user.id, user.role, s.access_ttl_min, sess.id)
    db.commit()
    return TokenOut(access_token=token, user=UserOut.model_validate(user))


@router.post("/logout", status_code=204)
def logout(request: Request, response: Response, db: Session = Depends(get_db)):
    if not _csrf_ok(request):
        raise HTTPException(403, "فشل التحقق من CSRF")
    raw = request.cookies.get(REFRESH)
    if raw:
        sess = db.scalar(select(UserSession).where(UserSession.refresh_hash == hash_token(raw)))
        if sess and not sess.revoked_at:
            sess.revoked_at = utcnow()
            audit(db, "auth.logout", request, sess.user_id)
            db.commit()
    response.delete_cookie(REFRESH, path="/api/auth")
    response.delete_cookie(CSRF, path="/")


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return user


@router.patch("/me", response_model=UserOut)
def update_me(body: ProfileIn, request: Request, user: User = Depends(get_current_user),
              db: Session = Depends(get_db)):
    user.full_name = body.full_name.strip()
    audit(db, "profile.update", request, user.id)
    db.commit()
    return user


@router.post("/change-password", status_code=204)
def change_password(body: ChangePasswordIn, request: Request, user: User = Depends(get_current_user),
                    db: Session = Depends(get_db)):
    if not verify_password(body.current_password, user.password_hash):
        raise HTTPException(400, "كلمة المرور الحالية غير صحيحة")
    problems = password_problems(body.new_password)
    if problems:
        raise HTTPException(422, "؛ ".join(problems))
    user.password_hash = hash_password(body.new_password)
    _revoke_all(db, user.id, except_id=request.state.session_id)
    audit(db, "auth.password_changed", request, user.id)
    db.commit()


@router.get("/sessions", response_model=list[SessionOut])
def sessions(request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(UserSession).where(
        UserSession.user_id == user.id, UserSession.revoked_at.is_(None),
        UserSession.expires_at > utcnow()).order_by(UserSession.last_used_at.desc())).all()
    return [SessionOut(id=r.id, user_agent=r.user_agent, ip=r.ip, created_at=r.created_at,
                       last_used_at=r.last_used_at, current=r.id == request.state.session_id) for r in rows]


@router.delete("/sessions/{session_id}", status_code=204)
def revoke_session(session_id: int, request: Request, user: User = Depends(get_current_user),
                   db: Session = Depends(get_db)):
    sess = db.get(UserSession, session_id)
    if not sess or sess.user_id != user.id:
        raise HTTPException(404, "الجلسة غير موجودة")
    sess.revoked_at = utcnow()
    audit(db, "auth.session_revoked", request, user.id, session_id=session_id)
    db.commit()


@router.post("/forgot-password", status_code=202, dependencies=[Depends(rate_limit("forgot", 5, 3600))])
def forgot_password(body: ForgotIn, request: Request, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == body.email.lower()))
    if user and user.is_active:
        db.execute(update(PasswordReset).where(PasswordReset.user_id == user.id,
                                               PasswordReset.used_at.is_(None)).values(used_at=utcnow()))
        token = new_token()
        db.add(PasswordReset(user_id=user.id, token_hash=hash_token(token),
                             expires_at=utcnow() + timedelta(minutes=30)))
        audit(db, "auth.reset_requested", request, user.id)
        db.commit()
        link = f"{get_settings().frontend_url}/reset-password?token={token}"
        send_email(user.email, "استعادة كلمة المرور - Cyber Shield Pro",
                   f"لإعادة تعيين كلمة المرور افتح الرابط (صالح 30 دقيقة):\n{link}\n\n"
                   "إن لم تطلب ذلك فتجاهل الرسالة.")
    return {"detail": "إن كان البريد مسجلاً فسيصلك رابط الاستعادة."}


@router.post("/reset-password", status_code=204, dependencies=[Depends(rate_limit("reset", 10, 3600))])
def reset_password(body: ResetIn, request: Request, db: Session = Depends(get_db)):
    pr = db.scalar(select(PasswordReset).where(PasswordReset.token_hash == hash_token(body.token)))
    if not pr or pr.used_at or _aware(pr.expires_at) < utcnow():
        raise HTTPException(400, "الرابط غير صالح أو منتهي")
    problems = password_problems(body.new_password)
    if problems:
        raise HTTPException(422, "؛ ".join(problems))
    user = db.get(User, pr.user_id)
    user.password_hash, user.failed_logins, user.locked_until = hash_password(body.new_password), 0, None
    pr.used_at = utcnow()
    _revoke_all(db, user.id)
    audit(db, "auth.password_reset", request, user.id)
    db.commit()
