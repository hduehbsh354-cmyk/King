from datetime import timedelta
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session, joinedload

from ..config import get_settings
from ..database import get_db
from ..deps import get_current_user, rate_limit
from ..models import Domain, Scan, User, utcnow
from ..schemas import ScanDetailOut, ScanIn, ScanOut
from ..services.audit import audit
from ..services.compare import compare_scans
from ..services.scan_runner import run_scan_job

router = APIRouter(prefix="/api/scans", tags=["scans"])


def _out(s: Scan, detail: bool = False):
    cls = ScanDetailOut if detail else ScanOut
    o = cls.model_validate(s)
    o.hostname = s.domain.hostname if s.domain else ""
    return o


def _get(db: Session, user: User, scan_id: int) -> Scan:
    s = db.scalar(select(Scan).options(joinedload(Scan.domain)).where(Scan.id == scan_id))
    if not s or (s.owner_id != user.id and user.role != "admin"):
        raise HTTPException(404, "الفحص غير موجود")
    return s


def _as_dict(s: Scan) -> dict:
    return {"score": s.score or 0, "findings": [
        {"check_id": f.check_id, "location": f.location, "title": f.title,
         "severity": f.severity, "recommendation": f.recommendation} for f in s.findings]}


@router.post("", response_model=ScanOut, status_code=202, dependencies=[Depends(rate_limit("scan", 30, 3600))])
def start_scan(body: ScanIn, request: Request, bg: BackgroundTasks,
               user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    cfg = get_settings()
    if not body.authorization_confirmed:
        raise HTTPException(422, "يجب تأكيد أنك تملك صلاحية فحص هذا النطاق.")
    d = db.get(Domain, body.domain_id)
    if not d or d.owner_id != user.id:
        raise HTTPException(404, "النطاق غير موجود")
    if not d.verified_at:
        raise HTTPException(403, "يجب إثبات ملكية النطاق قبل الفحص.")
    running = db.scalar(select(func.count()).select_from(Scan).where(
        Scan.owner_id == user.id, Scan.status.in_(("queued", "running"))))
    if running >= cfg.max_running_scans_per_user:
        raise HTTPException(429, "لديك فحوصات قيد التنفيذ، انتظر اكتمالها.")
    today = db.scalar(select(func.count()).select_from(Scan).where(
        Scan.owner_id == user.id, Scan.created_at > utcnow() - timedelta(days=1)))
    if today >= cfg.max_scans_per_day:
        raise HTTPException(429, "وصلت إلى الحد اليومي لعمليات الفحص.")
    s = Scan(owner_id=user.id, domain_id=d.id)
    db.add(s)
    db.flush()
    audit(db, "scan.start", request, user.id, scan_id=s.id, hostname=d.hostname)
    db.commit()
    s.domain = d
    bg.add_task(run_scan_job, s.id)
    return _out(s)


@router.get("", response_model=list[ScanOut])
def list_scans(domain_id: int = None, limit: int = Query(20, ge=1, le=100), offset: int = Query(0, ge=0),
               user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = select(Scan).options(joinedload(Scan.domain)).where(Scan.owner_id == user.id)
    if domain_id:
        q = q.where(Scan.domain_id == domain_id)
    rows = db.scalars(q.order_by(Scan.created_at.desc()).limit(limit).offset(offset)).all()
    return [_out(s) for s in rows]


@router.get("/{scan_id}", response_model=ScanDetailOut)
def get_scan(scan_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return _out(_get(db, user, scan_id), True)


@router.get("/{scan_id}/compare")
def compare(scan_id: int, with_id: int = Query(None, alias="with"),
            user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """يقارن الفحص بفحص سابق (الافتراضي: آخر فحص مكتمل قبله لنفس النطاق)."""
    new = _get(db, user, scan_id)
    if new.status != "completed":
        raise HTTPException(409, "الفحص لم يكتمل بعد")
    if with_id:
        old = _get(db, user, with_id)
    else:
        old = db.scalar(select(Scan).where(Scan.domain_id == new.domain_id, Scan.status == "completed",
                                           Scan.created_at < new.created_at).order_by(Scan.created_at.desc()).limit(1))
        if not old:
            raise HTTPException(404, "لا يوجد فحص سابق للمقارنة")
    if old.domain_id != new.domain_id or old.status != "completed":
        raise HTTPException(422, "المقارنة ممكنة فقط بين فحصين مكتملين لنفس النطاق")
    return {"old_scan_id": old.id, "new_scan_id": new.id, **compare_scans(_as_dict(old), _as_dict(new))}


@router.delete("/{scan_id}", status_code=204)
def delete_scan(scan_id: int, request: Request, user: User = Depends(get_current_user),
                db: Session = Depends(get_db)):
    s = _get(db, user, scan_id)
    if s.owner_id != user.id:
        raise HTTPException(403, "لا يمكنك حذف فحص مستخدم آخر")
    if s.status in ("queued", "running"):
        raise HTTPException(409, "لا يمكن حذف فحص قيد التنفيذ")
    audit(db, "scan.delete", request, user.id, scan_id=s.id)
    db.delete(s)
    db.commit()
