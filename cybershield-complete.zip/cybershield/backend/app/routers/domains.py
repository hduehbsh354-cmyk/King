from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..database import get_db
from ..deps import get_current_user, rate_limit
from ..models import Domain, User, utcnow
from ..scanner import ownership
from ..scanner.checks.dns_checks import DnsError, DnsPythonResolver
from ..scanner.ssrf import TargetNotAllowed, normalize_domain
from ..schemas import DomainIn, DomainOut
from ..services.audit import audit

router = APIRouter(prefix="/api/domains", tags=["domains"])


def _out(d: Domain, with_instructions: bool = False) -> DomainOut:
    o = DomainOut.model_validate(d)
    if with_instructions and not d.verified_at:
        o.verification = ownership.instructions(d.hostname, d.verification_token)
    return o


def _own(db: Session, user: User, domain_id: int) -> Domain:
    d = db.get(Domain, domain_id)
    if not d or d.owner_id != user.id:
        raise HTTPException(404, "النطاق غير موجود")
    return d


@router.post("", response_model=DomainOut, status_code=201)
def add_domain(body: DomainIn, request: Request, user: User = Depends(get_current_user),
               db: Session = Depends(get_db)):
    try:
        host = normalize_domain(body.hostname)
    except TargetNotAllowed as e:
        raise HTTPException(422, str(e))
    if db.scalar(select(func.count()).select_from(Domain).where(Domain.owner_id == user.id)) >= get_settings().max_domains_per_user:
        raise HTTPException(409, "وصلت إلى الحد الأقصى للنطاقات")
    if db.scalar(select(Domain).where(Domain.owner_id == user.id, Domain.hostname == host)):
        raise HTTPException(409, "هذا النطاق مضاف مسبقاً")
    d = Domain(owner_id=user.id, hostname=host, verification_token=ownership.generate_token())
    db.add(d)
    db.flush()
    audit(db, "domain.add", request, user.id, hostname=host)
    db.commit()
    return _out(d, True)


@router.get("", response_model=list[DomainOut])
def list_domains(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Domain).where(Domain.owner_id == user.id).order_by(Domain.created_at.desc())).all()
    return [_out(d, True) for d in rows]


@router.post("/{domain_id}/verify", response_model=DomainOut,
             dependencies=[Depends(rate_limit("verify", 20, 3600))])
def verify_domain(domain_id: int, request: Request, user: User = Depends(get_current_user),
                  db: Session = Depends(get_db)):
    d = _own(db, user, domain_id)
    if d.verified_at:
        return _out(d)
    try:
        dns = DnsPythonResolver()
    except DnsError:
        dns = None
    method = ownership.verify(d.hostname, d.verification_token, dns)
    if not method:
        audit(db, "domain.verify_failed", request, user.id, hostname=d.hostname)
        db.commit()
        raise HTTPException(400, "لم يُعثر على إثبات الملكية. تأكد من سجل DNS أو الملف ثم أعد المحاولة "
                                 "(قد يستغرق انتشار DNS بعض الوقت).")
    d.verified_at, d.verified_method = utcnow(), method
    audit(db, "domain.verified", request, user.id, hostname=d.hostname, method=method)
    db.commit()
    return _out(d)


@router.delete("/{domain_id}", status_code=204)
def delete_domain(domain_id: int, request: Request, user: User = Depends(get_current_user),
                  db: Session = Depends(get_db)):
    d = _own(db, user, domain_id)
    audit(db, "domain.delete", request, user.id, hostname=d.hostname)
    db.delete(d)
    db.commit()
