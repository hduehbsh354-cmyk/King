#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")/backend"
export ENV=development
export SECRET_KEY="${SECRET_KEY:-$(python -c 'import secrets;print(secrets.token_urlsafe(48))')}"
echo "افتح المتصفح على: http://localhost:8000"
exec python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
