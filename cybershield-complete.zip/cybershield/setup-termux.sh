#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg install -y python rust clang make libffi openssl
cd "$(dirname "$0")/backend"
pip install -r requirements-termux.txt
echo "تم التثبيت. شغّل: bash run.sh"
