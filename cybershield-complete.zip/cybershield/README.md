# Cyber Shield Pro (Backend + واجهة ويب)

## التشغيل على Termux
```bash
termux-setup-storage
cp -r /storage/emulated/0/Download/cybershield-complete/cybershield ~/
cd ~/cybershield
bash setup-termux.sh     # مرة واحدة
bash run.sh              # كل مرة
```
افتح المتصفح: http://localhost:8000  (التوثيق: /api/docs)

أول أدمن (في جلسة Termux ثانية):
`cd ~/cybershield/backend && python -m app.cli create-admin you@mail.com 'StrongPass123'`

## تدفق الاستخدام
حساب جديد ← إضافة نطاق تملكه ← إثبات الملكية (DNS TXT أو ملف) ← فحص ← النتائج والمقارنة.

## الاختبارات
`cd backend && python -m unittest discover -s tests -t .`

ملاحظة: الفحص يتطلب دومين حقيقي تملكه، ولا يعمل على localhost (حماية SSRF).
